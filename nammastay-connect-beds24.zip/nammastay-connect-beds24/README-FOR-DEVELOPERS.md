# NammaStay Connect — OTA sync through Beds24 (update 046)

Owners get their beds on **Booking.com, Agoda and Goibibo** for **₹1,665 a month per property (GST included)**.
NammaStay's team sets everything up ("Do it for me"), so owners never log into Beds24.
Owners who already have their own Beds24 account can link it themselves instead, and pay NammaStay nothing extra.

Beds24 is the channel manager that sits between NammaStay and the OTAs. NammaStay holds one master Beds24 account
with one sub-account per property. Beds24 bills per property, with no platform fee, so the owner's add-on pays for
it and NammaStay never pays up front.

**Speed (under 1 minute, usually seconds):**
- **Changes go out instantly.** Any booking, blocked bed or price change in NammaStay pings the `connect` function
  straight away (pg_net trigger, at most once every 10 s per property).
- **Bookings come in within seconds.** Beds24's booking webhook pings the `connect` function as soon as an OTA booking lands.
- **The every-minute cron is the backup.** If a ping is ever missed, the next minute catches it.

**Beds24 replaces Channex.** Channex no longer appears anywhere in the app or admin, and OTA sync (Beds24) takes its
place. The Channex database tables and the `channex` function are **not deleted**; they just stop being used
(see "Channex removed" below).

The database update is **additive**:
- 045's tables and functions are unchanged. The only change is a wider OTA-code check so that "beds24" fits.
- iCal calendar sync (020) keeps working exactly as before.
- Nothing is deleted.

This zip also contains phase 1 (045), so it **replaces `nammastay-connect-phase1.zip`**.

---

## Order: apply on top of release v2

1. **SQL** (Supabase → SQL Editor), in this order. Both files are safe to run twice.
   - `supabase/sql/updates/045_connect.sql` (skip it if you already ran phase 1)
   - `supabase/sql/updates/046_connect_beds24.sql`
2. **Settings for the instant ping.** Run this one line, using the same `CRON_SECRET` the functions use:
   ```sql
   update public.cn_settings set function_url = 'https://skcqpfyshbxcyyamsgtj.supabase.co/functions/v1/connect',
                                 cron_secret  = 'YOUR-CRON-SECRET' where id = 1;
   ```
   Without this line everything still works, but changes go out on the every-minute cron instead of instantly.
3. **Edge function.** Deploy the folder `supabase/functions/connect` (two files: `index.ts`, `adapters.ts`):
   `supabase functions deploy connect --no-verify-jwt`
   - The secret `CRON_SECRET` is already set for the other functions.
   - `BEDS24_API` is optional and defaults to `https://beds24.com/api/v2`.
4. **Schedule.** Run `supabase/sql/schedules/connect_schedule.sql` once, after replacing `YOUR-CRON-SECRET`.
   It runs every minute. If you already ran it for phase 1, keep it as it is.
5. **Stop Channex.** Run `supabase/sql/schedules/stop_channex_schedule.sql`. It stops the every-5-minutes Channex job.
   It is safe to run twice. To undo it, run `channex_schedule.sql` again.
6. **Website.** Copy `website/` over the site, keeping the same paths. These are full files (release v2 + additions):

| File | | Change to the existing file |
|---|---|---|
| `connections.html` | NEW: admin page *Admin → Connections* | — |
| `assets/js/pages/connections.js` | NEW: admin console + **OTA sync setup queue** (confirm payment → link → match rooms → tick OTAs → go live) | — |
| `assets/js/pages/connect-card.js` | NEW: owner card on *OTA sync*: offer, UPI payment, "accept Beds24 in each OTA" steps, live view, own-account link | — |
| `assets/js/core.js` | **"Connections" in the NammaStay admin menu** (sidebar + phone menu + the admin section inside the hostel app) | +10 lines, nothing removed: 1 menu entry, plus 9 lines so a menu the browser remembered from before also gets it |
| `assets/js/shell.js` | the remembered admin menu is shown on the Connections page too (no flash of the hostel menu) | `'connections.html'` added to one list |
| `assets/js/pages/ota.js` | OTA sync (Beds24) card on top; **Channex card no longer shown** | +3 / −2 lines: the Channex card's placeholder and call are replaced by the OTA sync card. `cxCard()` stays in the file, unused |
| `ota.html` | Channex frames removed from the page's security policy | one line |
| `assets/js/pages/admin.js` | admin header button **"Channel manager" → "OTA sync"** (opens Connections) | one line |
| `channel-manager.html` | the old Channex admin page now opens Connections | +1 line (redirect) |
| `privacy.html`, `terms.html`, `refund.html` | name Beds24 / OTA sync instead of Channex | one sentence each |
| `assets/js/demo-backend.js` | demo mode for the new screens | +169 lines, nothing removed |

Every other page is exactly as in release v2. The iCal calendar links on the OTA sync page are unchanged.
`CHANGES-TO-EXISTING-FILES.diff` shows every line changed in the existing files. Use it if the live copies differ from release v2.

Payments go to the UPI ID already set in `platform_settings`, the same one used for NammaStay plans.

**Undo:** run `supabase/sql/rollbacks/rollback_046_connect_beds24.sql` (and `rollback_045_connect.sql` to remove
phase 1 too), run `channex_schedule.sql` to bring Channex back, then put back the website files.

### Channex removed: what happens to it

- **Screens:** no Channex card for owners and no "Channel manager" button for admins.
  `channel-manager.html` opens Connections.
- **Kept, unused:**
  - the Channex tables (`channex_links`, `channex_room_map`, `channex_bookings`, `cx_settings`) and any saved Channex links
  - the `channex` edge function
  - `cxCard()` in `ota.js` and `channel-manager.js`

  Nothing breaks, and Channex can come back by undoing the website change and re-running `channex_schedule.sql`.
- **To delete Channex for good later** (optional, not needed now): run `supabase functions delete channex`,
  remove `channel-manager.html` / `channel-manager.js` / `cxCard()`, and drop the Channex tables. 044 has
  `rollback_044_channex_key.sql`, but 027 has no rollback file yet, so that clean-up script would need writing first.
- **A property linked to Channex in an OTA** (Booking.com: *Account → Connectivity provider*) must end that
  connection there before it can accept Beds24. The OTA sync steps tell the owner where to click.

---

## How it works

**Owner** (*OTA sync* page):
1. Taps **Turn on OTA sync**, pays ₹1,665 by UPI (QR or UPI app) and enters the UTR.
2. Accepts Beds24 as the channel manager in each OTA extranet (Booking.com, Agoda), and ticks each one as done.
   For Goibibo, they copy a ready-made message for their market manager.
3. Gets a notification when it's live. The card then shows the OTAs that are live, the last send and check times,
   the latest OTA reservations, **Sync now**, **Pause**, billing ("paid until …") and **Pay ahead**.

**NammaStay team** (*Admin → Connections → OTA sync setup*):
1. **Confirm payment.** This adds one month. **Not received** sends the owner a note.
2. **Link the sub-account.**
   - In Beds24, create a sub-account for the property and generate an API V2 **invite code** in it
     (read + write for properties, inventory and bookings).
   - Paste the code and press **Link**. The function exchanges it for keys (stored in `cn_secrets`, never shown).
     If the account has no property yet, it creates the property and one room per NammaStay room type, then
     **matches rooms by name**.
   - **Match rooms** lets you fix any match by hand.
3. **Inside Beds24:** connect Booking.com / Agoda / Goibibo (channel manager) and map the rooms there.
   Then tick those OTAs in NammaStay.
4. **Booking webhook.** Copy the link shown in step 4 into Beds24's booking webhook setting
   (*Settings → Properties → Access → Booking webhooks*). The link carries a 64-character key per property.
5. **Go live.** NammaStay sends the next 365 days, then reads every Beds24 booking that hasn't departed yet.
   ⚠ If the owner typed some OTA bookings into NammaStay by hand, cancel those copies after the first read.

**Billing:**
- Each confirmed payment moves "paid until" forward by one month.
- Seven days before the due date, the owner's card shows **Pay for next month**.
- After **3 days overdue**, the connection pauses by itself (`cn_b24_expire`, runs with the cron) and the owner is notified.
- Once the owner pays again and the team confirms the payment, the owner taps **Resume** on the card.

**Owner's own Beds24:** *Already use Beds24? Link your own account* → paste the invite code → the owner gets
the webhook link to paste in their Beds24. There is no NammaStay add-on in this case.

---

## Check against Beds24's Swagger before going live

Beds24's wiki doesn't spell out a few names. They are kept in **one place**, the `B24` object at the top of the
Beds24 section in `adapters.ts`. Check them at `beds24.com/api/v2` (Swagger) and change them there only:

| `B24` key | Current value | Used for |
|---|---|---|
| `inviteHeader` | `code` | `GET /authentication/setup`: the header that carries the invite code |
| `minStayField` | `minStay` | `POST /inventory/rooms/calendar`: minimum stay per date range |
| `changedFilter` | `modifiedFrom` | `GET /bookings`: "changed since" (each read starts 10 min before the last one) |
| `upcomingFilter` | `departureFrom` | `GET /bookings`: first read after linking |

Also confirm these:
- **Webhook payload.** NammaStay doesn't parse it. Any POST to the link with the right key starts a booking
  read, so the payload format doesn't matter.
- **Usage limit** (100 credits per 5 minutes per account). On a 429 the card says "trying again shortly" and
  the 2 → 64 min back-off applies. Availability is sent only for nights that changed, 20 rooms per call.
- **MakeMyTrip** is reached through Goibibo in Beds24's channel list. Confirm this for each property.

---

## Tests (all passing)

| Test | Checks |
|---|---|
| `tests/test_046_connect_beds24.sql` | **68** database checks: permissions (owner / manager / stranger / admin; secrets and setup tables closed), UPI UTR rules, duplicate UTR, confirm / reject, paid-until months, link save, auto-match, admin match (no duplicates), go-live rules, webhook key, one sync at a time, instant-ping trigger + 10 s debounce, pause after 3 days overdue, turn off, own account vs managed |
| `tests/test_045_connect.sql` | **50** phase-1 checks, still passing |
| `tests/e2e_beds24.mjs` | **48** checks running the real `connect` function against the database and a fake Beds24 API V2 server: link with invite code, property + rooms created (no duplicates on re-link), auto-match, 365-day push, change-only push, new / modified / cancelled bookings, group bookings, unmatched rooms flagged, unconfirmed requests ignored, webhook with good and bad keys, instant kick, token refresh, 429 back-off, no double runs, own-account link |
| `tests/e2e_connect_function.mjs` | **21** phase-1 checks, passing on 045 only and on 045 + 046 |
| `tests/ui_beds24.mjs` | **60** browser checks in demo mode, desktop + phone: owner offer → pay → steps → admin queue → go live → owner live view → turn off → own account; no JS errors, no sideways scroll |
| `tests/ui_connect.mjs` | **36** phase-1 browser checks, still passing |
| `tests/ui_no_channex.mjs` | **50** checks, desktop + phone: no Channex on the OTA sync page (hostel, hotel, homestay, resort), admin overview, Connections, privacy / terms / refund pages; OTA sync (Beds24) is the first card; iCal links still there; old Channex admin page opens Connections |
| `tests/ui_menu.mjs` | **31** menu checks, desktop + phone: "Connections" on every admin page, highlighted on its own page, opens from the menu (phone menu too), appears once in the admin section inside the hostel app, and is added to a menu the browser remembered from before; front desk still sees no OTA sync |

The function code also passes a strict TypeScript check. 046 was also tested installed twice, rolled back and installed again.

`tests/run_sql_tests.sh` runs both SQL suites against a local Postgres template database `cnbase`
(the project setup SQL plus the 004 seed).

`tests/screenshots/` shows what the screens look like.

## Existing code and database: what was checked

**Database**, on a copy with only the released updates (001–037, 039, 044; without the held-back 038 and 040–043):
- 045 and 046 install cleanly, and installing them twice is safe.
- Every existing table column, function, trigger, policy and sequence was compared before and after: **none changed or removed**.
  170 new `cn_…` objects were added. The only things touching existing tables are phase 1's four `cn_touch` triggers on
  `bookings`, `beds`, `bed_blocks` and `rate_rules`. They mark a live connection as "changed" and do nothing for
  properties without one.
- `5_security_checks.sql` gives the same results (RLS on every table, the same anonymous access, the same callable functions).
  The new tables only appear in its size list.
- The existing feature tests for 030, 031, 032, 033, 034, 036, 037 and 039 give **the same output** with and without Connect.
- The Connect tests pass on this database too: 045 (50), 046 (68), the Beds24 end-to-end test (48) and the phase-1 end-to-end test (21).
- Running both rollbacks returns the database to **exactly** how it was before.
- `stop_channex_schedule.sql` removes the Channex job, is safe to run twice, and `channex_schedule.sql` brings it back.

**Website:** every page for hostel, hotel, homestay and PG, as owner, manager, front desk and accountant, on desktop and
phone, compared with release v2 (no JS errors, no sideways scroll, same menus apart from "Connections").
