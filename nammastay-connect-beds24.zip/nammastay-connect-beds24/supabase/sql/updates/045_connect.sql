-- =====================================================================
-- NammaStay · 045_connect.sql — NammaStay Connect: NammaStay's own OTA connectivity
--   NammaStay → OTA : availability (free beds/rooms per night), price and minimum stay,
--                     only the nights that changed (a full refresh once a day)
--   OTA → NammaStay : reservations (new / modified / cancelled) with guest details,
--                     confirmed back to the OTA
-- One connection per property per OTA. Each OTA has an adapter in the `connect`
-- edge function. "Test OTA" is a built-in simulator so the whole flow can be tried
-- and certified before an OTA (Booking.com, MakeMyTrip…) approves NammaStay.
-- A real OTA only goes live after a NammaStay admin switches it on
-- (Admin → Connections), i.e. once that OTA has approved NammaStay as a partner.
-- Additive: nothing existing is changed (Channex 027 and iCal 020 keep working).
-- No card numbers are ever stored.
-- Run AFTER 044_channex_key.sql (needs 027's cx_groups and 026's _night_rate).
-- =====================================================================

-- ---------------------------------------------------------------- OTAs NammaStay can talk to
create table if not exists public.cn_otas (
  ota        text primary key check (ota ~ '^[a-z]{2,20}$'),
  name       text not null,
  enabled    boolean not null default false,          -- switched on by a NammaStay admin once the OTA has approved NammaStay
  hotel_id_hint text,
  sort       int not null default 0,
  updated_at timestamptz not null default now()
);
insert into public.cn_otas (ota, name, enabled, hotel_id_hint, sort) values
  ('booking',     'Booking.com',           false, 'Booking.com property ID — the number next to the property name in the extranet', 1),
  ('mmt',         'MakeMyTrip / Goibibo',  false, 'MakeMyTrip Hotel ID (InGo-MMT extranet)', 2),
  ('agoda',       'Agoda',                 false, 'Agoda Hotel ID (YCS)', 3),
  ('expedia',     'Expedia',               false, 'Expedia property ID (Partner Central)', 4),
  ('hostelworld', 'Hostelworld',           false, 'Hostelworld property number (Inbox)', 5),
  ('test',        'Test OTA (simulator)',  true,  'Any code, e.g. TEST-001', 99)
on conflict (ota) do nothing;

-- ---------------------------------------------------------------- connections
create table if not exists public.cn_connections (
  id            uuid primary key default gen_random_uuid(),
  property_id   uuid not null references public.properties(id) on delete cascade,
  ota           text not null references public.cn_otas(ota),
  ota_hotel_id  text not null check (char_length(ota_hotel_id) between 1 and 40),
  status        text not null default 'setup' check (status in ('setup','waiting','live','paused')),
  dirty_at      timestamptz not null default now(),
  full_at       timestamptz,                           -- last full (365-day) refresh
  last_push_at  timestamptz,
  last_pull_at  timestamptz,
  last_error    text check (char_length(last_error) <= 500),
  fails         int not null default 0,
  retry_at      timestamptz,
  created_by    uuid,
  created_at    timestamptz not null default now(),
  unique (property_id, ota)
);
create index if not exists cn_connections_ota on public.cn_connections (ota, status);

-- NammaStay room + price group  ↔  OTA room type + rate plan
create table if not exists public.cn_room_map (
  connection_id uuid not null references public.cn_connections(id) on delete cascade,
  group_key     text not null,                         -- room_id:rate_paise (same grouping as 027)
  room_id       uuid not null,
  rate_paise    int  not null,
  title         text not null,
  bed_ids       uuid[] not null,
  ota_room_id   text check (char_length(ota_room_id) <= 60),
  ota_rate_id   text check (char_length(ota_rate_id) <= 60),
  primary key (connection_id, group_key)
);
-- Room types / rate plans as the OTA reports them (for the matching dropdowns)
create table if not exists public.cn_ota_rooms (
  connection_id uuid not null references public.cn_connections(id) on delete cascade,
  ota_room_id   text not null,
  ota_rate_id   text not null default '',
  room_name     text not null,
  rate_name     text,
  primary key (connection_id, ota_room_id, ota_rate_id)
);
-- What was last sent to the OTA per group and night (so only changes are sent)
create table if not exists public.cn_ari_sent (
  connection_id uuid not null references public.cn_connections(id) on delete cascade,
  group_key     text not null,
  day           date not null,
  avail         int  not null,
  rate_paise    int  not null,
  min_stay      int  not null,
  sent_at       timestamptz not null default now(),
  primary key (connection_id, group_key, day)
);
-- Reservations received from the OTA
create table if not exists public.cn_reservations (
  connection_id uuid not null references public.cn_connections(id) on delete cascade,
  ota_res_id    text not null,
  property_id   uuid not null references public.properties(id) on delete cascade,
  status        text,
  revision      text,
  ota_code      text,
  booking_ids   uuid[] not null default '{}',
  guest_name    text,
  arrival       date,
  departure     date,
  amount        numeric(12,2),
  currency      text,
  problem       text check (char_length(problem) <= 300),
  confirmed_at  timestamptz,
  raw           jsonb,
  received_at   timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  primary key (connection_id, ota_res_id)
);
create index if not exists cn_reservations_prop on public.cn_reservations (property_id, received_at desc);
-- Message log (every request/response; proof for OTA certification)
create table if not exists public.cn_log (
  id            bigserial primary key,
  connection_id uuid not null references public.cn_connections(id) on delete cascade,
  at            timestamptz not null default now(),
  dir           text not null check (dir in ('out','in','info')),
  kind          text not null check (char_length(kind) <= 40),
  ok            boolean not null default true,
  summary       text check (char_length(summary) <= 300),
  detail        text check (char_length(detail) <= 20000)
);
create index if not exists cn_log_conn on public.cn_log (connection_id, at desc);

-- ---------------------------------------------------------------- Test OTA (simulator) storage
create table if not exists public.cn_sim_ari (
  connection_id uuid not null references public.cn_connections(id) on delete cascade,
  ota_room_id   text not null,
  ota_rate_id   text not null default '',
  day           date not null,
  avail         int  not null,
  rate_paise    int  not null,
  min_stay      int  not null,
  updated_at    timestamptz not null default now(),
  primary key (connection_id, ota_room_id, ota_rate_id, day)
);
create table if not exists public.cn_sim_res (
  id            bigserial primary key,
  connection_id uuid not null references public.cn_connections(id) on delete cascade,
  payload       jsonb not null,
  delivered_at  timestamptz,
  confirmed_at  timestamptz,
  created_at    timestamptz not null default now()
);

do $$ declare t text; begin
  foreach t in array array['cn_otas','cn_connections','cn_room_map','cn_ota_rooms','cn_ari_sent','cn_reservations','cn_log','cn_sim_ari','cn_sim_res'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on public.%I from anon, authenticated', t);
  end loop;
end $$;

-- ---------------------------------------------------------------- "something changed — send it"
create or replace function public._cn_touch() returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  update public.cn_connections set dirty_at = now()
   where property_id = coalesce(new.property_id, old.property_id) and status = 'live';
  return coalesce(new, old);
end $$;
do $$ declare t text; begin
  foreach t in array array['bookings','bed_blocks','rate_rules','beds'] loop
    execute format('drop trigger if exists cn_touch on public.%I', t);
    execute format('create trigger cn_touch after insert or update or delete on public.%I for each row execute function public._cn_touch()', t);
  end loop;
end $$;

-- ---------------------------------------------------------------- helpers
create or replace function public._cn_conn_role(p_connection uuid, p_roles public.member_role[]) returns public.cn_connections
language plpgsql security definer set search_path = public, pg_temp as $$
declare c public.cn_connections%rowtype;
begin
  select * into c from public.cn_connections where id = p_connection;
  if not found then raise exception 'Connection not found.' using errcode = 'P0002'; end if;
  perform public._assert_role(c.property_id, p_roles);
  return c;
end $$;

-- Refresh the group list of a connection (new rooms / price groups appear unmapped; mapped ones keep their OTA ids)
create or replace function public._cn_sync_groups(p_connection uuid) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare c public.cn_connections%rowtype; g jsonb;
begin
  select * into c from public.cn_connections where id = p_connection;
  for g in select * from jsonb_array_elements(public.cx_groups(c.property_id)) loop
    insert into public.cn_room_map (connection_id, group_key, room_id, rate_paise, title, bed_ids)
    values (p_connection, g->>'group_key', (g->>'room_id')::uuid, (g->>'rate_paise')::int, g->>'title',
            array(select x::uuid from jsonb_array_elements_text(g->'bed_ids') x))
    on conflict (connection_id, group_key) do update set title = excluded.title, bed_ids = excluded.bed_ids;
  end loop;
  -- groups that no longer exist (room removed / price changed): keep the row only if it is still mapped, with no beds
  update public.cn_room_map m set bed_ids = '{}'
   where m.connection_id = p_connection
     and not exists (select 1 from jsonb_array_elements(public.cx_groups(c.property_id)) gg where gg->>'group_key' = m.group_key);
  delete from public.cn_room_map m where m.connection_id = p_connection and m.ota_room_id is null and cardinality(m.bed_ids) = 0;
end $$;

-- ---------------------------------------------------------------- staff (owner / manager)
create or replace function public.cn_status(p_property uuid) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_admin boolean := public.is_platform_admin(); v_c uuid;
begin
  perform public._assert_role(p_property, array['owner','manager']::public.member_role[]);
  for v_c in select id from public.cn_connections where property_id = p_property loop perform public._cn_sync_groups(v_c); end loop;
  return jsonb_build_object(
    'is_admin', v_admin,
    'otas', (select coalesce(jsonb_agg(jsonb_build_object('ota', o.ota, 'name', o.name, 'enabled', o.enabled, 'hint', o.hotel_id_hint) order by o.sort), '[]'::jsonb)
             from public.cn_otas o where o.ota <> 'test' or v_admin),
    'connections', (select coalesce(jsonb_agg(jsonb_build_object(
        'id', c.id, 'ota', c.ota, 'ota_name', o.name, 'ota_enabled', o.enabled, 'ota_hotel_id', c.ota_hotel_id, 'status', c.status,
        'last_push_at', c.last_push_at, 'last_pull_at', c.last_pull_at, 'last_error', c.last_error, 'retry_at', c.retry_at,
        'maps', (select coalesce(jsonb_agg(jsonb_build_object('group_key', m.group_key, 'title', m.title, 'rate_paise', m.rate_paise, 'units', cardinality(m.bed_ids),
                   'ota_room_id', m.ota_room_id, 'ota_rate_id', m.ota_rate_id) order by m.title), '[]'::jsonb) from public.cn_room_map m where m.connection_id = c.id),
        'ota_rooms', (select coalesce(jsonb_agg(jsonb_build_object('ota_room_id', r.ota_room_id, 'ota_rate_id', r.ota_rate_id, 'room_name', r.room_name, 'rate_name', r.rate_name)
                   order by r.room_name, r.rate_name), '[]'::jsonb) from public.cn_ota_rooms r where r.connection_id = c.id),
        'reservations', (select coalesce(jsonb_agg(jsonb_build_object('ota_res_id', x.ota_res_id, 'code', x.ota_code, 'status', x.status, 'guest', x.guest_name,
                   'arrival', x.arrival, 'departure', x.departure, 'amount', x.amount, 'currency', x.currency, 'problem', x.problem, 'booking_ids', x.booking_ids,
                   'received_at', x.received_at) order by x.received_at desc), '[]'::jsonb)
                 from (select * from public.cn_reservations where connection_id = c.id order by received_at desc limit 20) x)
      ) order by o.sort), '[]'::jsonb)
      from public.cn_connections c join public.cn_otas o on o.ota = c.ota where c.property_id = p_property));
end $$;

create or replace function public.cn_save_connection(p_property uuid, p_ota text, p_hotel_id text) returns uuid
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_id uuid; v_hid text := btrim(coalesce(p_hotel_id, ''));
begin
  perform public._assert_role(p_property, array['owner']::public.member_role[]);
  if not exists (select 1 from public.cn_otas where ota = p_ota) then raise exception 'Unknown OTA.'; end if;
  if p_ota = 'test' and not public.is_platform_admin() then raise exception 'The Test OTA is only for NammaStay admins.' using errcode = '42501'; end if;
  if v_hid = '' then raise exception 'Enter the % ID.', (select name from public.cn_otas where ota = p_ota); end if;
  if p_ota = 'booking' and v_hid !~ '^[0-9]{4,12}$' then raise exception 'The Booking.com property ID is numbers only (4–12 digits).'; end if;
  if v_hid !~ '^[A-Za-z0-9._-]{1,40}$' then raise exception 'The ID can only have letters, numbers, dots, dashes and underscores.'; end if;
  if exists (select 1 from public.cn_connections where ota = p_ota and ota_hotel_id = v_hid and property_id <> p_property) then
    raise exception 'This % ID is already connected to another NammaStay property.', (select name from public.cn_otas where ota = p_ota);
  end if;
  insert into public.cn_connections (property_id, ota, ota_hotel_id, created_by) values (p_property, p_ota, v_hid, auth.uid())
  on conflict (property_id, ota) do update set ota_hotel_id = excluded.ota_hotel_id, last_error = null
  returning id into v_id;
  perform public._cn_sync_groups(v_id);
  insert into public.cn_log (connection_id, dir, kind, summary) values (v_id, 'info', 'connection', 'Connection saved with ID ' || v_hid);
  return v_id;
end $$;

create or replace function public.cn_save_map(p_connection uuid, p_maps jsonb) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare c public.cn_connections%rowtype; m jsonb; v_room text; v_rate text;
begin
  c := public._cn_conn_role(p_connection, array['owner','manager']::public.member_role[]);
  for m in select * from jsonb_array_elements(coalesce(p_maps, '[]'::jsonb)) loop
    v_room := nullif(btrim(coalesce(m->>'ota_room_id', '')), ''); v_rate := nullif(btrim(coalesce(m->>'ota_rate_id', '')), '');
    if v_room is not null and v_room !~ '^[A-Za-z0-9._:-]{1,60}$' then raise exception 'OTA room codes can only have letters, numbers, dots, dashes, colons and underscores.'; end if;
    if v_rate is not null and v_rate !~ '^[A-Za-z0-9._:-]{1,60}$' then raise exception 'OTA rate codes can only have letters, numbers, dots, dashes, colons and underscores.'; end if;
    update public.cn_room_map set ota_room_id = v_room, ota_rate_id = v_rate where connection_id = p_connection and group_key = m->>'group_key';
  end loop;
  if exists (select 1 from public.cn_room_map where connection_id = p_connection and ota_room_id is not null
             group by ota_room_id, coalesce(ota_rate_id, '') having count(*) > 1) then
    raise exception 'Two NammaStay rooms are matched to the same OTA room and rate. Each OTA room/rate can be used once.';
  end if;
  update public.cn_connections set dirty_at = now(), full_at = null where id = p_connection;
end $$;

-- Owner: go live. Live straight away if the OTA is switched on; otherwise "waiting" until NammaStay's OTA approval.
create or replace function public.cn_go_live(p_connection uuid) returns text
language plpgsql security definer set search_path = public, pg_temp as $$
declare c public.cn_connections%rowtype; v_on boolean; v_st text;
begin
  c := public._cn_conn_role(p_connection, array['owner']::public.member_role[]);
  perform public._cn_sync_groups(p_connection);
  if not exists (select 1 from public.cn_room_map where connection_id = p_connection and ota_room_id is not null and cardinality(bed_ids) > 0) then
    raise exception 'Match at least one room to an OTA room first.';
  end if;
  select enabled into v_on from public.cn_otas where ota = c.ota;
  v_st := case when v_on then 'live' else 'waiting' end;
  update public.cn_connections set status = v_st, dirty_at = now(), full_at = null, fails = 0, retry_at = null, last_error = null where id = p_connection;
  insert into public.cn_log (connection_id, dir, kind, summary) values (p_connection, 'info', 'status',
    case when v_on then 'Went live' else 'Waiting — this OTA isn''t switched on for NammaStay yet' end);
  return v_st;
end $$;

create or replace function public.cn_pause(p_connection uuid, p_paused boolean) returns text
language plpgsql security definer set search_path = public, pg_temp as $$
declare c public.cn_connections%rowtype; v_st text;
begin
  c := public._cn_conn_role(p_connection, array['owner']::public.member_role[]);
  if p_paused then v_st := 'paused';
  elsif c.status = 'paused' then v_st := case when (select enabled from public.cn_otas where ota = c.ota) then 'live' else 'waiting' end;
  else v_st := c.status; end if;
  update public.cn_connections set status = v_st, dirty_at = now(), full_at = null where id = p_connection;
  insert into public.cn_log (connection_id, dir, kind, summary) values (p_connection, 'info', 'status', case when p_paused then 'Paused' else 'Resumed' end);
  return v_st;
end $$;

create or replace function public.cn_resync(p_connection uuid) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  perform public._cn_conn_role(p_connection, array['owner','manager']::public.member_role[]);
  update public.cn_connections set dirty_at = now(), full_at = null, retry_at = null where id = p_connection;
end $$;

create or replace function public.cn_delete(p_connection uuid) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  perform public._cn_conn_role(p_connection, array['owner']::public.member_role[]);
  delete from public.cn_connections where id = p_connection;
end $$;

-- Edge function check: may this signed-in user act on this connection?
create or replace function public.cn_check(p_connection uuid) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare c public.cn_connections%rowtype;
begin
  c := public._cn_conn_role(p_connection, array['owner','manager']::public.member_role[]);
  return jsonb_build_object('id', c.id, 'property_id', c.property_id, 'ota', c.ota, 'status', c.status);
end $$;

-- ---------------------------------------------------------------- NammaStay admins
create or replace function public.cn_admin_overview() returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  perform public._assert_platform_admin();
  return jsonb_build_object(
    'otas', (select coalesce(jsonb_agg(jsonb_build_object('ota', o.ota, 'name', o.name, 'enabled', o.enabled,
               'connections', (select count(*) from public.cn_connections c where c.ota = o.ota),
               'waiting', (select count(*) from public.cn_connections c where c.ota = o.ota and c.status = 'waiting')) order by o.sort), '[]'::jsonb)
             from public.cn_otas o),
    'connections', (select coalesce(jsonb_agg(jsonb_build_object('id', c.id, 'property', p.name, 'property_id', c.property_id, 'ota', c.ota, 'ota_name', o.name,
               'ota_hotel_id', c.ota_hotel_id, 'status', c.status, 'last_push_at', c.last_push_at, 'last_pull_at', c.last_pull_at, 'last_error', c.last_error,
               'fails', c.fails, 'retry_at', c.retry_at,
               'mapped', (select count(*) from public.cn_room_map m where m.connection_id = c.id and m.ota_room_id is not null),
               'groups', (select count(*) from public.cn_room_map m where m.connection_id = c.id and cardinality(m.bed_ids) > 0),
               'problems', (select count(*) from public.cn_reservations r where r.connection_id = c.id and r.problem is not null and r.received_at > now() - interval '30 days'),
               'reservations', (select count(*) from public.cn_reservations r where r.connection_id = c.id)) order by p.name, o.sort), '[]'::jsonb)
             from public.cn_connections c join public.properties p on p.id = c.property_id join public.cn_otas o on o.ota = c.ota));
end $$;

create or replace function public.cn_admin_log(p_connection uuid, p_limit int default 60) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  perform public._assert_platform_admin();
  return (select coalesce(jsonb_agg(jsonb_build_object('id', l.id, 'at', l.at, 'dir', l.dir, 'kind', l.kind, 'ok', l.ok, 'summary', l.summary,
            'detail', left(l.detail, 4000)) order by l.at desc, l.id desc), '[]'::jsonb)
    from (select * from public.cn_log where connection_id = p_connection order by at desc, id desc limit least(greatest(coalesce(p_limit, 60), 1), 500)) l);
end $$;

-- Switch an OTA on once it has approved NammaStay; waiting connections go live
create or replace function public.cn_admin_set_ota(p_ota text, p_enabled boolean) returns int
language plpgsql security definer set search_path = public, pg_temp as $$
declare n int := 0;
begin
  perform public._assert_platform_admin();
  update public.cn_otas set enabled = p_enabled, updated_at = now() where ota = p_ota;
  if not found then raise exception 'Unknown OTA.'; end if;
  if p_enabled then
    update public.cn_connections set status = 'live', dirty_at = now(), full_at = null where ota = p_ota and status = 'waiting';
    get diagnostics n = row_count;
  else
    update public.cn_connections set status = 'waiting' where ota = p_ota and status = 'live';
    get diagnostics n = row_count;
  end if;
  return n;
end $$;

create or replace function public.cn_admin_retry(p_connection uuid) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  perform public._assert_platform_admin();
  update public.cn_connections set retry_at = null, fails = 0, dirty_at = now(), full_at = null where id = p_connection;
end $$;

-- Test OTA: what the "OTA" currently shows (proof that pushes arrive)
create or replace function public.cn_admin_sim_view(p_connection uuid, p_days int default 14) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  perform public._assert_platform_admin();
  return (select coalesce(jsonb_agg(jsonb_build_object('ota_room_id', s.ota_room_id, 'ota_rate_id', s.ota_rate_id, 'day', s.day, 'avail', s.avail,
            'rate_paise', s.rate_paise, 'min_stay', s.min_stay) order by s.ota_room_id, s.ota_rate_id, s.day), '[]'::jsonb)
    from public.cn_sim_ari s where s.connection_id = p_connection and s.day between current_date and current_date + least(greatest(coalesce(p_days, 14), 1), 60) - 1);
end $$;

-- Test OTA: a guest books / cancels on the "OTA"
create or replace function public.cn_admin_sim_booking(p_connection uuid, p jsonb) returns text
language plpgsql security definer set search_path = public, pg_temp as $$
declare c public.cn_connections%rowtype; v_res text; v_in date; v_n int; v_room text; v_old jsonb; v_rate int;
begin
  perform public._assert_platform_admin();
  select * into c from public.cn_connections where id = p_connection;
  if not found or c.ota <> 'test' then raise exception 'Only for Test OTA connections.'; end if;
  if p->>'cancel' is not null then
    select payload into v_old from public.cn_sim_res where connection_id = p_connection and payload->>'res_id' = p->>'cancel' order by id desc limit 1;
    if v_old is null then raise exception 'Test reservation not found.'; end if;
    insert into public.cn_sim_res (connection_id, payload) values (p_connection,
      v_old || jsonb_build_object('status', 'cancelled', 'revision', 'r' || extract(epoch from clock_timestamp())::bigint));
    return p->>'cancel';
  end if;
  v_room := coalesce(nullif(p->>'ota_room_id', ''), (select ota_room_id from public.cn_room_map where connection_id = p_connection and ota_room_id is not null order by title limit 1));
  if v_room is null then raise exception 'Match a room first.'; end if;
  v_in := coalesce(nullif(p->>'checkin', '')::date, current_date + 3); v_n := least(greatest(coalesce(nullif(p->>'nights', '')::int, 2), 1), 30);
  select coalesce(max(rate_paise), 70000) into v_rate from public.cn_sim_ari where connection_id = p_connection and ota_room_id = v_room and day = v_in;
  v_res := 'T' || to_char(clock_timestamp(), 'YYMMDDHH24MISSMS');
  insert into public.cn_sim_res (connection_id, payload) values (p_connection, jsonb_build_object(
    'res_id', v_res, 'revision', 'r1', 'status', 'new', 'ota_code', v_res,
    'customer', jsonb_build_object('name', coalesce(nullif(p->>'guest', ''), 'Test'), 'surname', 'Guest', 'phone', '+919800000000', 'mail', 'test.guest@example.com', 'country', 'IN'),
    'rooms', jsonb_build_array(jsonb_build_object('ota_room_id', v_room, 'checkin_date', v_in, 'checkout_date', v_in + v_n, 'amount', round(v_rate * v_n / 100.0, 2), 'adults', 1)),
    'amount', round(v_rate * v_n / 100.0, 2), 'currency', 'INR', 'arrival_date', v_in, 'departure_date', v_in + v_n, 'payment_collect', 'property',
    'notes', 'Test OTA reservation'));
  return v_res;
end $$;

-- ---------------------------------------------------------------- server (edge function, service role)
create or replace function public.cn_due() returns jsonb
language sql stable security definer set search_path = public, pg_temp as $$
  select coalesce(jsonb_agg(jsonb_build_object('id', c.id, 'ota', c.ota,
           'push', c.last_push_at is null or c.dirty_at > c.last_push_at or c.full_at is null or c.full_at < now() - interval '1 day',
           'full', c.full_at is null or c.full_at < now() - interval '1 day')), '[]'::jsonb)
    from public.cn_connections c join public.cn_otas o on o.ota = c.ota
   where c.status = 'live' and o.enabled and (c.retry_at is null or c.retry_at <= now())
     and public._access_state(c.property_id) not in ('expired','suspended')
$$;

create or replace function public.cn_conn(p_connection uuid) returns jsonb
language sql stable security definer set search_path = public, pg_temp as $$
  select jsonb_build_object('id', c.id, 'property_id', c.property_id, 'ota', c.ota, 'ota_hotel_id', c.ota_hotel_id, 'status', c.status,
           'ota_enabled', o.enabled, 'property', jsonb_build_object('name', p.name, 'timezone', p.timezone, 'kind', p.kind),
           'groups', (select coalesce(jsonb_agg(jsonb_build_object('group_key', m.group_key, 'title', m.title, 'units', cardinality(m.bed_ids), 'rate_paise', m.rate_paise,
                        'ota_room_id', m.ota_room_id, 'ota_rate_id', m.ota_rate_id) order by m.title), '[]'::jsonb) from public.cn_room_map m where m.connection_id = c.id))
    from public.cn_connections c join public.cn_otas o on o.ota = c.ota join public.properties p on p.id = c.property_id where c.id = p_connection
$$;

-- Nights to send: availability, price and minimum stay per mapped group; only changed nights unless p_full
create or replace function public.cn_ari_changes(p_connection uuid, p_days int default 365, p_full boolean default false) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare c public.cn_connections%rowtype; p public.properties%rowtype; d0 date;
begin
  select * into c from public.cn_connections where id = p_connection;
  select * into p from public.properties where id = c.property_id;
  perform public._cn_sync_groups(p_connection);
  d0 := (now() at time zone p.timezone)::date;
  delete from public.cn_ari_sent where connection_id = p_connection and day < d0;
  return (select coalesce(jsonb_agg(jsonb_build_object('group_key', n.group_key, 'ota_room_id', n.ota_room_id, 'ota_rate_id', n.ota_rate_id,
            'date', n.d, 'avail', n.avail, 'rate_paise', n.rate, 'min_stay', n.min_stay) order by n.ota_room_id, n.ota_rate_id, n.d), '[]'::jsonb)
    from (
      select m.group_key, m.ota_room_id, coalesce(m.ota_rate_id, '') as ota_rate_id, d::date as d,
        (select count(*) from unnest(m.bed_ids) bid
          where exists (select 1 from public.beds b where b.id = bid and b.is_active)
            and not exists (select 1 from public.bookings k where k.bed_id = bid and k.status in ('pending','confirmed','checked_in')
                             and k.stay && tstzrange(((d::date)::timestamp + p.checkin_time) at time zone p.timezone,
                                                     ((d::date + 1)::timestamp + p.checkout_time) at time zone p.timezone, '[)'))
            and not exists (select 1 from public.bed_blocks z where z.bed_id = bid
                             and z.period && tstzrange(((d::date)::timestamp + p.checkin_time) at time zone p.timezone,
                                                       ((d::date + 1)::timestamp + p.checkout_time) at time zone p.timezone, '[)')))::int as avail,
        public._night_rate(c.property_id, m.room_id, m.rate_paise, d::date) as rate,
        greatest(1, coalesce((select max(r.min_nights) from public.rate_rules r
                    where r.property_id = c.property_id and r.is_active and r.min_nights is not null and (r.room_ids is null or m.room_id = any (r.room_ids))
                      and ((r.kind = 'season' and d::date between r.date_from and r.date_to)
                        or (r.kind = 'weekend' and extract(dow from d)::smallint = any (r.weekdays)))), 1))::int as min_stay
      from public.cn_room_map m cross join generate_series(d0, d0 + least(greatest(coalesce(p_days, 365), 1), 500) - 1, interval '1 day') d
     where m.connection_id = p_connection and m.ota_room_id is not null) n
    left join public.cn_ari_sent s on s.connection_id = p_connection and s.group_key = n.group_key and s.day = n.d
    where p_full or s.day is null or (s.avail, s.rate_paise, s.min_stay) is distinct from (n.avail, n.rate, n.min_stay));
end $$;

-- After a successful send: remember what the OTA now has
create or replace function public.cn_ari_ack(p_connection uuid, p_rows jsonb, p_full boolean default false) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  insert into public.cn_ari_sent (connection_id, group_key, day, avail, rate_paise, min_stay, sent_at)
  select p_connection, r->>'group_key', (r->>'date')::date, (r->>'avail')::int, (r->>'rate_paise')::int, (r->>'min_stay')::int, now()
    from jsonb_array_elements(coalesce(p_rows, '[]'::jsonb)) r
  on conflict (connection_id, group_key, day) do update set avail = excluded.avail, rate_paise = excluded.rate_paise, min_stay = excluded.min_stay, sent_at = now();
  update public.cn_connections set last_push_at = now(), full_at = case when p_full then now() else full_at end,
         fails = 0, retry_at = null, last_error = null where id = p_connection;
end $$;

-- Mark success / failure (failures back off: 2, 4, 8 … 64 minutes)
create or replace function public.cn_mark(p_connection uuid, p_kind text, p_error text default null) returns void
language sql security definer set search_path = public, pg_temp as $$
  update public.cn_connections set
    last_pull_at = case when p_kind = 'pull' and p_error is null then now() else last_pull_at end,
    last_error = case when p_error is null then case when p_kind = 'pull' then last_error else null end else left(p_error, 500) end,
    fails = case when p_error is null then fails else fails + 1 end,
    retry_at = case when p_error is null then retry_at else now() + make_interval(mins => power(2, least(fails + 1, 6))::int) end
  where id = p_connection
$$;

create or replace function public.cn_log_add(p_connection uuid, p_dir text, p_kind text, p_ok boolean, p_summary text, p_detail text default null) returns void
language sql security definer set search_path = public, pg_temp as $$
  insert into public.cn_log (connection_id, dir, kind, ok, summary, detail)
  values (p_connection, p_dir, left(p_kind, 40), coalesce(p_ok, true), left(p_summary, 300), left(p_detail, 20000));
  delete from public.cn_log where connection_id = p_connection and at < now() - interval '45 days';
$$;

create or replace function public.cn_rooms_save(p_connection uuid, p_rooms jsonb) returns int
language plpgsql security definer set search_path = public, pg_temp as $$
declare n int;
begin
  delete from public.cn_ota_rooms where connection_id = p_connection;
  insert into public.cn_ota_rooms (connection_id, ota_room_id, ota_rate_id, room_name, rate_name)
  select distinct on (r->>'ota_room_id', coalesce(r->>'ota_rate_id', '')) p_connection, left(r->>'ota_room_id', 60), left(coalesce(r->>'ota_rate_id', ''), 60),
         left(coalesce(nullif(r->>'room_name', ''), r->>'ota_room_id'), 120), left(r->>'rate_name', 120)
    from jsonb_array_elements(coalesce(p_rooms, '[]'::jsonb)) r where coalesce(r->>'ota_room_id', '') <> '';
  get diagnostics n = row_count;
  return n;
end $$;

-- OTA reservation → NammaStay booking(s). p_res is the normalised reservation every adapter returns:
-- {res_id, revision, status: new|modified|cancelled, ota_code, customer{name,surname,phone,mail,country},
--  rooms:[{ota_room_id, ota_rate_id?, checkin_date, checkout_date, amount, adults}], amount, currency,
--  arrival_date, departure_date, notes, payment_collect: ota|property}. Idempotent per revision.
create or replace function public.cn_import(p_connection uuid, p_res jsonb) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  c public.cn_connections%rowtype; p public.properties%rowtype; o public.cn_otas%rowtype; v_row public.cn_reservations%rowtype;
  v_res text := p_res->>'res_id'; v_status text := lower(coalesce(p_res->>'status', 'new')); v_ids uuid[] := '{}'; v_problem text; rm jsonb;
  m public.cn_room_map%rowtype; v_in timestamptz; v_out timestamptz; v_n int; v_bed uuid; v_guest uuid; v_total int; v_rate int; v_bk uuid;
  v_name text; v_phone text; v_mail text; v_code text := coalesce(nullif(p_res->>'ota_code', ''), p_res->>'res_id'); k record; v_note text; v_ota text;
begin
  select * into c from public.cn_connections where id = p_connection;
  if not found then raise exception 'Connection not found.'; end if;
  select * into p from public.properties where id = c.property_id;
  select * into o from public.cn_otas where ota = c.ota;
  v_ota := regexp_replace(o.name, ' \(.*\)$', '');
  if coalesce(v_res, '') = '' then raise exception 'Reservation without an id.'; end if;
  if v_status not in ('new','modified','cancelled') then raise exception 'Unknown reservation status %.', v_status; end if;
  select * into v_row from public.cn_reservations where connection_id = p_connection and ota_res_id = v_res for update;
  if found and v_row.revision = coalesce(p_res->>'revision', '') then return jsonb_build_object('duplicate', true, 'booking_ids', v_row.booking_ids); end if;

  if found and v_status in ('cancelled','modified') then
    for k in select * from public.bookings where id = any (v_row.booking_ids) loop
      if k.status in ('pending','confirmed') then
        update public.bookings set status = 'cancelled', cancelled_at = now(), note = left(concat_ws(E'\n', note, v_ota || ' ' || v_status), 2000) where id = k.id;
      elsif k.status = 'checked_in' then
        v_problem := format('%s %s reservation %s, but the guest is already checked in — please adjust by hand.', v_ota, v_status, v_code);
        v_ids := v_ids || k.id;
      end if;
    end loop;
  end if;

  if v_status in ('new','modified') and v_problem is null then
    v_name := nullif(btrim(concat_ws(' ', p_res->'customer'->>'name', p_res->'customer'->>'surname')), '');
    if v_name is null or char_length(v_name) < 2 then v_name := v_ota || ' guest ' || coalesce(v_code, ''); end if;
    v_phone := regexp_replace(coalesce(p_res->'customer'->>'phone', ''), '[^0-9+]', '', 'g');
    if v_phone !~ '^\+?[0-9]{8,15}$' then v_phone := null; end if;
    v_mail := nullif(btrim(coalesce(p_res->'customer'->>'mail', '')), '');
    if v_mail is not null and v_mail !~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' then v_mail := null; end if;
    select id into v_guest from public.guests where property_id = c.property_id
       and ((v_mail is not null and lower(email) = lower(v_mail)) or (v_phone is not null and phone = v_phone)) order by created_at limit 1;
    if v_guest is null then
      insert into public.guests (property_id, full_name, phone, email, nationality)
      values (c.property_id, left(v_name, 120), v_phone, v_mail, nullif(p_res->'customer'->>'country', '')) returning id into v_guest;
    end if;
    perform set_config('nammastay.skip_rate_rules', '1', true);
    for rm in select * from jsonb_array_elements(coalesce(p_res->'rooms', '[]'::jsonb)) loop
      continue when coalesce((rm->>'is_cancelled')::boolean, false);
      select * into m from public.cn_room_map where connection_id = p_connection and ota_room_id = rm->>'ota_room_id'
         and (coalesce(rm->>'ota_rate_id', '') = '' or coalesce(ota_rate_id, '') = '' or ota_rate_id = rm->>'ota_rate_id')
       order by (ota_rate_id = rm->>'ota_rate_id') desc nulls last limit 1;
      if not found then v_problem := format('%s reservation %s: OTA room %s isn''t matched to a NammaStay room.', v_ota, v_code, rm->>'ota_room_id'); continue; end if;
      v_in := ((rm->>'checkin_date')::date::timestamp + p.checkin_time) at time zone p.timezone;
      v_out := ((rm->>'checkout_date')::date::timestamp + p.checkout_time) at time zone p.timezone;
      v_n := greatest(1, (rm->>'checkout_date')::date - (rm->>'checkin_date')::date);
      select bid into v_bed from unnest(m.bed_ids) with ordinality u(bid, ord)
       where exists (select 1 from public.beds b where b.id = bid and b.is_active)
         and not exists (select 1 from public.bookings x where x.bed_id = bid and x.status in ('pending','confirmed','checked_in') and x.stay && tstzrange(v_in, v_out, '[)'))
         and not exists (select 1 from public.bed_blocks z where z.bed_id = bid and z.period && tstzrange(v_in, v_out, '[)'))
       order by ord limit 1;
      if v_bed is null then
        v_problem := format('%s reservation %s (%s → %s): no free %s in %s — possible overbooking, please move a guest.',
                            v_ota, v_code, rm->>'checkin_date', rm->>'checkout_date', case when p.kind = 'hostel' then 'bed' else 'room' end, m.title);
        continue;
      end if;
      v_total := round(coalesce(nullif(rm->>'amount', '')::numeric, nullif(p_res->>'amount', '')::numeric, 0) * 100);
      v_rate := round(v_total::numeric / v_n);
      v_note := left(concat_ws(E'\n', format('%s · %s', v_ota, v_code),
                  case when p_res->>'payment_collect' = 'ota' then 'Paid to ' || v_ota || ' (collect nothing at the desk unless told otherwise)' end,
                  case when coalesce(p_res->>'currency', 'INR') <> 'INR' then 'Amount in ' || (p_res->>'currency') end,
                  nullif(p_res->>'notes', '')), 2000);
      begin
        insert into public.bookings (property_id, guest_id, bed_id, visitors, check_in_at, check_out_at, nights, rate_paise, total_paise, status, source, note, created_by)
        values (c.property_id, v_guest, v_bed, least(greatest(coalesce((rm->>'adults')::int, 1), 1), 20), v_in, v_out, v_n, v_rate, v_rate * v_n,
                'confirmed', 'ota', v_note, null)
        returning id into v_bk;
        v_ids := v_ids || v_bk;
      exception when exclusion_violation then
        v_problem := format('%s reservation %s: the %s was just taken — please place it by hand.', v_ota, v_code, case when p.kind = 'hostel' then 'bed' else 'room' end);
      end;
    end loop;
    perform set_config('nammastay.skip_rate_rules', '', true);
  end if;

  insert into public.cn_reservations as r (connection_id, ota_res_id, property_id, status, revision, ota_code, booking_ids, guest_name, arrival, departure,
       amount, currency, problem, raw, updated_at)
  values (p_connection, v_res, c.property_id, v_status, coalesce(p_res->>'revision', ''), v_code, v_ids, v_name,
          nullif(p_res->>'arrival_date', '')::date, nullif(p_res->>'departure_date', '')::date, nullif(p_res->>'amount', '')::numeric, p_res->>'currency',
          v_problem, (p_res - 'card') - 'payment_card', now())
  on conflict (connection_id, ota_res_id) do update set status = excluded.status, revision = excluded.revision, booking_ids = excluded.booking_ids,
     guest_name = coalesce(excluded.guest_name, r.guest_name), arrival = excluded.arrival, departure = excluded.departure, amount = excluded.amount,
     currency = excluded.currency, problem = excluded.problem, raw = excluded.raw, updated_at = now();

  insert into public.notifications (property_id, kind, title, body, booking_id)
  values (c.property_id, case when v_problem is not null then 'ota_clash' else 'booking' end,
          case when v_problem is not null then '⚠ ' || v_ota || ' reservation needs attention'
               when v_status = 'cancelled' then v_ota || ' reservation cancelled' when v_status = 'modified' then v_ota || ' reservation changed'
               else 'New ' || v_ota || ' reservation' end,
          coalesce(v_problem, format('%s · %s → %s · %s', coalesce(v_name, v_row.guest_name, ''), p_res->>'arrival_date', p_res->>'departure_date', v_code)),
          v_ids[1]);
  perform public.cn_log_add(p_connection, 'in', 'reservation', v_problem is null,
          format('%s %s %s', initcap(v_status), v_code, coalesce(v_problem, '→ ' || cardinality(v_ids) || ' booking(s)')), null);
  return jsonb_build_object('booking_ids', v_ids, 'problem', v_problem);
end $$;

create or replace function public.cn_res_confirmed(p_connection uuid, p_res_ids text[]) returns void
language sql security definer set search_path = public, pg_temp as $$
  update public.cn_reservations set confirmed_at = now() where connection_id = p_connection and ota_res_id = any (p_res_ids)
$$;

-- Test OTA: receive a push / hand out reservations / mark them confirmed
create or replace function public.cn_sim_push(p_connection uuid, p_rows jsonb) returns int
language plpgsql security definer set search_path = public, pg_temp as $$
declare n int;
begin
  insert into public.cn_sim_ari (connection_id, ota_room_id, ota_rate_id, day, avail, rate_paise, min_stay, updated_at)
  select p_connection, r->>'ota_room_id', coalesce(r->>'ota_rate_id', ''), (r->>'date')::date, (r->>'avail')::int, (r->>'rate_paise')::int, (r->>'min_stay')::int, now()
    from jsonb_array_elements(coalesce(p_rows, '[]'::jsonb)) r
  on conflict (connection_id, ota_room_id, ota_rate_id, day) do update set avail = excluded.avail, rate_paise = excluded.rate_paise, min_stay = excluded.min_stay, updated_at = now();
  get diagnostics n = row_count;
  return n;
end $$;
create or replace function public.cn_sim_pull(p_connection uuid) returns jsonb
language sql security definer set search_path = public, pg_temp as $$
  with x as (update public.cn_sim_res set delivered_at = coalesce(delivered_at, now())
              where connection_id = p_connection and confirmed_at is null returning id, payload)
  select coalesce(jsonb_agg(payload order by id), '[]'::jsonb) from x
$$;
create or replace function public.cn_sim_confirm(p_connection uuid, p_res_ids text[]) returns void
language sql security definer set search_path = public, pg_temp as $$
  update public.cn_sim_res set confirmed_at = now() where connection_id = p_connection and payload->>'res_id' = any (p_res_ids) and confirmed_at is null
$$;
create or replace function public.cn_sim_rooms(p_connection uuid) returns jsonb
language sql stable security definer set search_path = public, pg_temp as $$
  select coalesce(jsonb_agg(jsonb_build_object('ota_room_id', 'TR' || lpad(n::text, 3, '0'), 'ota_rate_id', 'STD',
           'room_name', title || ' (Test OTA)', 'rate_name', 'Standard rate') order by n), '[]'::jsonb)
    from (select title, row_number() over (order by title) n from public.cn_room_map where connection_id = p_connection and cardinality(bed_ids) > 0) g
$$;

-- ---------------------------------------------------------------- permissions
do $$ declare f text; begin
  foreach f in array array[
    'public._cn_touch()', 'public._cn_conn_role(uuid, public.member_role[])', 'public._cn_sync_groups(uuid)',
    'public.cn_status(uuid)', 'public.cn_save_connection(uuid, text, text)', 'public.cn_save_map(uuid, jsonb)', 'public.cn_go_live(uuid)',
    'public.cn_pause(uuid, boolean)', 'public.cn_resync(uuid)', 'public.cn_delete(uuid)', 'public.cn_check(uuid)',
    'public.cn_admin_overview()', 'public.cn_admin_log(uuid, int)', 'public.cn_admin_set_ota(text, boolean)', 'public.cn_admin_retry(uuid)',
    'public.cn_admin_sim_view(uuid, int)', 'public.cn_admin_sim_booking(uuid, jsonb)',
    'public.cn_due()', 'public.cn_conn(uuid)', 'public.cn_ari_changes(uuid, int, boolean)', 'public.cn_ari_ack(uuid, jsonb, boolean)',
    'public.cn_mark(uuid, text, text)', 'public.cn_log_add(uuid, text, text, boolean, text, text)', 'public.cn_rooms_save(uuid, jsonb)',
    'public.cn_import(uuid, jsonb)', 'public.cn_res_confirmed(uuid, text[])',
    'public.cn_sim_push(uuid, jsonb)', 'public.cn_sim_pull(uuid)', 'public.cn_sim_confirm(uuid, text[])', 'public.cn_sim_rooms(uuid)'] loop
    execute format('revoke execute on function %s from public, anon, authenticated', f);
  end loop;
  foreach f in array array[
    'public.cn_status(uuid)', 'public.cn_save_connection(uuid, text, text)', 'public.cn_save_map(uuid, jsonb)', 'public.cn_go_live(uuid)',
    'public.cn_pause(uuid, boolean)', 'public.cn_resync(uuid)', 'public.cn_delete(uuid)', 'public.cn_check(uuid)',
    'public.cn_admin_overview()', 'public.cn_admin_log(uuid, int)', 'public.cn_admin_set_ota(text, boolean)', 'public.cn_admin_retry(uuid)',
    'public.cn_admin_sim_view(uuid, int)', 'public.cn_admin_sim_booking(uuid, jsonb)'] loop
    execute format('grant execute on function %s to authenticated', f);
  end loop;
  foreach f in array array[
    'public.cn_due()', 'public.cn_conn(uuid)', 'public.cn_ari_changes(uuid, int, boolean)', 'public.cn_ari_ack(uuid, jsonb, boolean)',
    'public.cn_mark(uuid, text, text)', 'public.cn_log_add(uuid, text, text, boolean, text, text)', 'public.cn_rooms_save(uuid, jsonb)',
    'public.cn_import(uuid, jsonb)', 'public.cn_res_confirmed(uuid, text[])',
    'public.cn_sim_push(uuid, jsonb)', 'public.cn_sim_pull(uuid)', 'public.cn_sim_confirm(uuid, text[])', 'public.cn_sim_rooms(uuid)'] loop
    execute format('grant execute on function %s to service_role', f);
  end loop;
end $$;
