-- =====================================================================
-- NammaStay · 046_connect_beds24.sql — OTA sync through Beds24 ("Do it for me")
--   One NammaStay Connect channel, Beds24, carries a property to Booking.com, Agoda, Goibibo…
--   • Owner: turns on OTA sync, pays the add-on by UPI (UTR), accepts Beds24 in each OTA extranet.
--   • NammaStay team (Admin → Connections → OTA sync setup): confirms the payment, makes a Beds24
--     sub-account, links it with an invite code (the connect function builds the rooms), ticks the
--     OTAs linked inside Beds24, turns on the booking webhook, and takes it live.
--   • Owners who already use Beds24 can link their own account instead (no add-on).
--   • Speed: any change pings the connect function straight away (pg_net, max once per 10 s per
--     connection), Beds24's booking webhook pings it for bookings, and the every-minute cron is the backup.
-- Additive: 045's tables and functions are unchanged (only the OTA-code check is widened so "beds24" fits).
-- Run AFTER 045_connect.sql. Then fill cn_settings (see the end of this file).
-- =====================================================================

-- ---------------------------------------------------------------- Beds24 as a channel (needs no OTA approval → on)
alter table public.cn_otas drop constraint if exists cn_otas_ota_check;
alter table public.cn_otas add constraint cn_otas_ota_check check (ota ~ '^[a-z][a-z0-9]{1,19}$');
insert into public.cn_otas (ota, name, enabled, hotel_id_hint, sort) values
  ('beds24', 'Beds24 (Booking.com, Agoda, Goibibo…)', true, 'Beds24 property ID (numbers)', 0)
on conflict (ota) do nothing;

-- ---------------------------------------------------------------- settings (one row)
create table if not exists public.cn_settings (
  id                   int primary key default 1 check (id = 1),
  ota_sync_price_paise int not null default 166500 check (ota_sync_price_paise between 0 and 10000000),   -- ₹1,665 a month, GST included
  function_url         text check (function_url is null or function_url ~ '^https://[^[:space:]]+/functions/v1/connect$'),
  cron_secret          text check (cron_secret is null or char_length(cron_secret) between 8 and 200),
  updated_at           timestamptz not null default now()
);
insert into public.cn_settings (id) values (1) on conflict (id) do nothing;

-- ---------------------------------------------------------------- per-property OTA sync setup
create table if not exists public.cn_b24_setup (
  property_id     uuid primary key references public.properties(id) on delete cascade,
  managed         boolean not null default true,              -- true = "Do it for me" (NammaStay's Beds24 account); false = owner's own Beds24
  state           text not null default 'requested' check (state in ('requested','paid','linked','live','cancelled')),
  connection_id   uuid references public.cn_connections(id) on delete set null,
  b24_property_id text check (b24_property_id is null or b24_property_id ~ '^[0-9]{1,12}$'),
  payments        jsonb not null default '[]'::jsonb,         -- [{utr, amount_paise, submitted_at, status: pending|approved|rejected, note, period_end}]
  paid_until      date,
  owner_steps     jsonb not null default '{}'::jsonb,         -- {"booking": "<when the owner accepted Beds24>", "agoda": …, "goibibo": …}
  otas_linked     jsonb not null default '{}'::jsonb,         -- {"booking": true, …} ticked by NammaStay's team after matching rooms in Beds24
  hook_key        text not null default (replace(gen_random_uuid()::text, '-', '') || replace(gen_random_uuid()::text, '-', '')),
  last_hook_at    timestamptz,
  requested_by    uuid,
  requested_at    timestamptz not null default now(),
  live_at         timestamptz,
  updated_at      timestamptz not null default now()
);
-- Beds24 keys per connection (server only — never readable from the browser)
create table if not exists public.cn_secrets (
  connection_id     uuid primary key references public.cn_connections(id) on delete cascade,
  refresh_token     text check (char_length(refresh_token) <= 2000),
  access_token      text check (char_length(access_token) <= 4000),
  access_expires_at timestamptz,
  updated_at        timestamptz not null default now()
);
-- "send now" pings (debounce) and one-run-at-a-time leases
create table if not exists public.cn_kicks (
  connection_id uuid primary key references public.cn_connections(id) on delete cascade,
  kicked_at     timestamptz not null default now()
);
create table if not exists public.cn_leases (
  connection_id uuid primary key references public.cn_connections(id) on delete cascade,
  until         timestamptz not null
);

do $$ declare t text; begin
  foreach t in array array['cn_settings','cn_b24_setup','cn_secrets','cn_kicks','cn_leases'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on public.%I from anon, authenticated', t);
  end loop;
end $$;

-- ---------------------------------------------------------------- helpers
create or replace function public._b24_status_json(p_property uuid, p_with_key boolean) returns jsonb
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare s public.cn_b24_setup%rowtype; c public.cn_connections%rowtype;
begin
  select * into s from public.cn_b24_setup where property_id = p_property;
  select * into c from public.cn_connections where property_id = p_property and ota = 'beds24';
  return jsonb_build_object(
    'price_paise', (select ota_sync_price_paise from public.cn_settings where id = 1),
    'pay_to', (select jsonb_build_object('upi_id', upi_id, 'payee_name', payee_name) from public.platform_settings where id = 1),
    'setup', case when s.property_id is null then null else jsonb_build_object(
        'managed', s.managed, 'state', s.state, 'paid_until', s.paid_until, 'payments', s.payments,
        'owner_steps', s.owner_steps, 'otas_linked', s.otas_linked, 'b24_property_id', s.b24_property_id,
        'requested_at', s.requested_at, 'live_at', s.live_at, 'last_hook_at', s.last_hook_at,
        'hook_key', case when p_with_key then s.hook_key end) end,
    'connection', case when c.id is null then null else jsonb_build_object(
        'id', c.id, 'status', c.status, 'ota_hotel_id', c.ota_hotel_id, 'last_push_at', c.last_push_at,
        'last_pull_at', c.last_pull_at, 'last_error', c.last_error, 'retry_at', c.retry_at,
        'mapped', (select count(*) from public.cn_room_map m where m.connection_id = c.id and m.ota_room_id is not null and cardinality(m.bed_ids) > 0),
        'groups', (select count(*) from public.cn_room_map m where m.connection_id = c.id and cardinality(m.bed_ids) > 0)) end);
end $$;

-- ---------------------------------------------------------------- owner / manager
create or replace function public.cn_b24_status(p_property uuid) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_managed boolean;
begin
  perform public._assert_role(p_property, array['owner','manager']::public.member_role[]);
  perform public._cn_sync_groups(c.id) from public.cn_connections c where c.property_id = p_property and c.ota = 'beds24';
  select managed into v_managed from public.cn_b24_setup where property_id = p_property;
  -- the webhook link is shown to owners only for their own Beds24 account (NammaStay's team handles managed ones)
  return public._b24_status_json(p_property, public.is_platform_admin() or (v_managed is false and exists (
    select 1 from public.property_members where property_id = p_property and user_id = auth.uid() and role = 'owner')));
end $$;

-- Owner turns on OTA sync (or pays the next month): UPI transaction ID for the add-on price
create or replace function public.cn_b24_pay(p_property uuid, p_utr text) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_utr text := upper(regexp_replace(coalesce(p_utr, ''), '\s', '', 'g')); v_price int; v_pay jsonb; s public.cn_b24_setup%rowtype;
begin
  perform public._assert_role(p_property, array['owner']::public.member_role[]);
  if v_utr !~ '^[0-9A-Z]{6,35}$' then raise exception 'Enter the UPI transaction ID (UTR) from your payment screen.'; end if;
  if exists (select 1 from public.cn_b24_setup x cross join jsonb_array_elements(x.payments) e where e->>'utr' = v_utr) then
    raise exception 'This UPI transaction was already submitted.';
  end if;
  select * into s from public.cn_b24_setup where property_id = p_property;
  if found and not s.managed and s.state <> 'cancelled' then
    raise exception 'Your own Beds24 account is linked — there''s nothing to pay NammaStay for OTA sync.';
  end if;
  select ota_sync_price_paise into v_price from public.cn_settings where id = 1;
  v_pay := jsonb_build_object('utr', v_utr, 'amount_paise', v_price, 'submitted_at', now(), 'status', 'pending');
  insert into public.cn_b24_setup (property_id, managed, state, requested_by, payments)
  values (p_property, true, 'requested', auth.uid(), jsonb_build_array(v_pay))
  on conflict (property_id) do update set
    payments   = public.cn_b24_setup.payments || jsonb_build_array(v_pay),
    managed    = true,
    state      = case when public.cn_b24_setup.state = 'cancelled' then 'requested' else public.cn_b24_setup.state end,
    requested_at = case when public.cn_b24_setup.state = 'cancelled' then now() else public.cn_b24_setup.requested_at end,
    updated_at = now();
  return public.cn_b24_status(p_property);
end $$;

-- Owner ticks "I've accepted Beds24" for an OTA (booking / agoda / goibibo)
create or replace function public.cn_b24_owner_step(p_property uuid, p_ota text, p_done boolean) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  perform public._assert_role(p_property, array['owner']::public.member_role[]);
  if p_ota not in ('booking','agoda','goibibo') then raise exception 'Unknown OTA.'; end if;
  update public.cn_b24_setup set
    owner_steps = case when p_done then owner_steps || jsonb_build_object(p_ota, now()) else owner_steps - p_ota end,
    updated_at = now()
   where property_id = p_property and state <> 'cancelled';
  if not found then raise exception 'Turn on OTA sync first.'; end if;
  return public.cn_b24_status(p_property);
end $$;

-- Owner stops OTA sync: the connection pauses (bookings already made stay)
create or replace function public.cn_b24_cancel(p_property uuid) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_conn uuid;
begin
  perform public._assert_role(p_property, array['owner']::public.member_role[]);
  update public.cn_b24_setup set state = 'cancelled', updated_at = now() where property_id = p_property returning connection_id into v_conn;
  if not found then raise exception 'OTA sync isn''t on.'; end if;
  if v_conn is not null then
    update public.cn_connections set status = 'paused' where id = v_conn and status <> 'paused';
    insert into public.cn_log (connection_id, dir, kind, summary) values (v_conn, 'info', 'status', 'Paused — the owner turned OTA sync off');
  end if;
  return public.cn_b24_status(p_property);
end $$;

-- Edge function check before linking a Beds24 account: NammaStay admin links a managed ("Do it for me") account;
-- an owner links their own Beds24 (p_own) — also when that owner is a NammaStay admin.
drop function if exists public.cn_b24_can_link(uuid);
create or replace function public.cn_b24_can_link(p_property uuid, p_own boolean default false) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare s public.cn_b24_setup%rowtype; v_has boolean;
begin
  select * into s from public.cn_b24_setup where property_id = p_property;
  v_has := found;
  if public.is_platform_admin() and not coalesce(p_own, false) then
    if not exists (select 1 from public.properties where id = p_property) then raise exception 'Property not found.'; end if;
    return jsonb_build_object('admin', true, 'managed', coalesce(s.managed, true));
  end if;
  perform public._assert_role(p_property, array['owner']::public.member_role[]);
  if v_has and s.managed and s.state <> 'cancelled' then
    raise exception 'NammaStay''s team sets up OTA sync for you — there''s nothing to link here.';
  end if;
  return jsonb_build_object('admin', public.is_platform_admin(), 'managed', false);
end $$;

-- ---------------------------------------------------------------- NammaStay admins
create or replace function public.cn_b24_queue() returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  perform public._assert_platform_admin();
  perform public._cn_sync_groups(s.connection_id) from public.cn_b24_setup s where s.connection_id is not null and s.state <> 'cancelled';
  return (select coalesce(jsonb_agg(jsonb_build_object(
      'property_id', s.property_id, 'property', p.name, 'city', p.city, 'kind', p.kind, 'phone', p.phone,
      'units', (select count(*) from public.beds b where b.property_id = s.property_id and b.is_active),
      'owner', (select coalesce(m.email, u.email) from public.property_members m join auth.users u on u.id = m.user_id
                 where m.property_id = s.property_id and m.role = 'owner' order by m.created_at limit 1),
      'managed', s.managed, 'state', s.state, 'payments', s.payments, 'paid_until', s.paid_until,
      'owner_steps', s.owner_steps, 'otas_linked', s.otas_linked, 'b24_property_id', s.b24_property_id,
      'hook_key', s.hook_key, 'last_hook_at', s.last_hook_at, 'requested_at', s.requested_at, 'live_at', s.live_at,
      'connection', case when c.id is null then null else jsonb_build_object('id', c.id, 'status', c.status, 'ota_hotel_id', c.ota_hotel_id,
          'last_push_at', c.last_push_at, 'last_pull_at', c.last_pull_at, 'last_error', c.last_error,
          'maps', (select coalesce(jsonb_agg(jsonb_build_object('group_key', m.group_key, 'title', m.title, 'rate_paise', m.rate_paise, 'units', cardinality(m.bed_ids),
                     'ota_room_id', m.ota_room_id, 'ota_rate_id', m.ota_rate_id) order by m.title), '[]'::jsonb) from public.cn_room_map m where m.connection_id = c.id),
          'ota_rooms', (select coalesce(jsonb_agg(jsonb_build_object('ota_room_id', r.ota_room_id, 'ota_rate_id', r.ota_rate_id, 'room_name', r.room_name, 'rate_name', r.rate_name)
                     order by r.room_name), '[]'::jsonb) from public.cn_ota_rooms r where r.connection_id = c.id)) end
    ) order by (s.state = 'live'), s.requested_at), '[]'::jsonb)
    from public.cn_b24_setup s join public.properties p on p.id = s.property_id left join public.cn_connections c on c.id = s.connection_id
   where s.state <> 'cancelled');
end $$;

-- Confirm (or reject) an OTA sync payment: confirmed adds one month
create or replace function public.cn_b24_admin_pay(p_property uuid, p_utr text, p_approve boolean, p_note text default null) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare s public.cn_b24_setup%rowtype; v_end date; v_found boolean := false; v_list jsonb := '[]'::jsonb; e jsonb;
begin
  perform public._assert_platform_admin();
  select * into s from public.cn_b24_setup where property_id = p_property for update;
  if not found then raise exception 'No OTA sync request for this property.'; end if;
  v_end := (greatest(coalesce(s.paid_until, current_date), current_date) + interval '1 month')::date;
  for e in select x from jsonb_array_elements(s.payments) x loop
    if e->>'utr' = upper(btrim(coalesce(p_utr, ''))) and e->>'status' = 'pending' and not v_found then
      v_found := true;
      e := e || jsonb_build_object('status', case when p_approve then 'approved' else 'rejected' end, 'note', nullif(left(btrim(coalesce(p_note, '')), 200), ''),
                                   'reviewed_at', now(), 'period_end', case when p_approve then v_end end);
    end if;
    v_list := v_list || jsonb_build_array(e);
  end loop;
  if not v_found then raise exception 'No pending payment with that UTR.'; end if;
  update public.cn_b24_setup set payments = v_list,
         paid_until = case when p_approve then v_end else paid_until end,
         state = case when p_approve and state = 'requested' then 'paid' else state end,
         updated_at = now()
   where property_id = p_property;
  insert into public.notifications (property_id, kind, title, body)
  values (p_property, 'ota_sync', case when p_approve then 'OTA sync payment confirmed' else 'OTA sync payment not confirmed' end,
          case when p_approve then format('Paid until %s. Thank you!', to_char(v_end, 'DD Mon YYYY'))
               else coalesce(nullif(btrim(coalesce(p_note, '')), ''), 'We couldn''t find this UPI transaction. Please check the UTR and submit it again.') end);
  return public._b24_status_json(p_property, true);
end $$;

-- Team's checklist: Beds24 property ID and which OTAs are linked + matched inside Beds24
create or replace function public.cn_b24_admin_set(p_property uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_ids text := nullif(btrim(coalesce(p->>'b24_property_id', '')), ''); v_otas jsonb := '{}'::jsonb; k text;
begin
  perform public._assert_platform_admin();
  if not exists (select 1 from public.cn_b24_setup where property_id = p_property) then raise exception 'No OTA sync request for this property.'; end if;
  if v_ids is not null and v_ids !~ '^[0-9]{1,12}$' then raise exception 'The Beds24 property ID is numbers only.'; end if;
  if p ? 'otas_linked' then
    for k in select jsonb_object_keys(p->'otas_linked') loop
      if k not in ('booking','agoda','goibibo') then raise exception 'Unknown OTA %.', k; end if;
      if coalesce((p->'otas_linked'->>k)::boolean, false) then v_otas := v_otas || jsonb_build_object(k, true); end if;
    end loop;
  end if;
  update public.cn_b24_setup set
    b24_property_id = case when p ? 'b24_property_id' then v_ids else b24_property_id end,
    otas_linked = case when p ? 'otas_linked' then v_otas else otas_linked end,
    updated_at = now()
   where property_id = p_property;
  return public._b24_status_json(p_property, true);
end $$;

-- Team matches NammaStay room types to Beds24 rooms (owners use cn_save_map for their own account)
create or replace function public.cn_b24_admin_map(p_connection uuid, p_maps jsonb) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare m jsonb; v_room text;
begin
  perform public._assert_platform_admin();
  if not exists (select 1 from public.cn_connections where id = p_connection and ota = 'beds24') then raise exception 'Not a Beds24 connection.'; end if;
  for m in select * from jsonb_array_elements(coalesce(p_maps, '[]'::jsonb)) loop
    v_room := nullif(btrim(coalesce(m->>'ota_room_id', '')), '');
    if v_room is not null and v_room !~ '^[0-9]{1,12}$' then raise exception 'Beds24 room IDs are numbers only.'; end if;
    update public.cn_room_map set ota_room_id = v_room, ota_rate_id = null where connection_id = p_connection and group_key = m->>'group_key';
  end loop;
  if exists (select 1 from public.cn_room_map where connection_id = p_connection and ota_room_id is not null group by ota_room_id having count(*) > 1) then
    raise exception 'Two NammaStay room types are matched to the same Beds24 room. Each Beds24 room can be used once.';
  end if;
  update public.cn_connections set dirty_at = now(), full_at = null where id = p_connection;
end $$;

-- Team takes it live: paid, linked, rooms matched, at least one OTA linked in Beds24
create or replace function public.cn_b24_admin_go_live(p_property uuid) returns text
language plpgsql security definer set search_path = public, pg_temp as $$
declare s public.cn_b24_setup%rowtype;
begin
  perform public._assert_platform_admin();
  select * into s from public.cn_b24_setup where property_id = p_property for update;
  if not found or s.state = 'cancelled' then raise exception 'No OTA sync request for this property.'; end if;
  if s.managed and (s.paid_until is null or s.paid_until < current_date) then raise exception 'Confirm the payment first.'; end if;
  if s.connection_id is null then raise exception 'Link the Beds24 sub-account first.'; end if;
  perform public._cn_sync_groups(s.connection_id);
  if not exists (select 1 from public.cn_room_map where connection_id = s.connection_id and ota_room_id is not null and cardinality(bed_ids) > 0) then
    raise exception 'Match at least one room type to a Beds24 room first.';
  end if;
  if not exists (select 1 from jsonb_each_text(s.otas_linked) where value = 'true') then
    raise exception 'Tick at least one OTA that is linked and matched inside Beds24.';
  end if;
  update public.cn_connections set status = 'live', dirty_at = now(), full_at = null, fails = 0, retry_at = null, last_error = null where id = s.connection_id;
  update public.cn_b24_setup set state = 'live', live_at = coalesce(live_at, now()), updated_at = now() where property_id = p_property;
  insert into public.cn_log (connection_id, dir, kind, summary) values (s.connection_id, 'info', 'status', 'Went live (OTA sync set up by NammaStay)');
  insert into public.notifications (property_id, kind, title, body)
  values (p_property, 'ota_sync', 'OTA sync is live',
          'Your beds and prices now update on ' || (select string_agg(case k when 'booking' then 'Booking.com' when 'agoda' then 'Agoda' else 'Goibibo' end, ', ' order by k)
                                                     from jsonb_each_text(s.otas_linked) x(k, v) where v = 'true') || ' automatically.');
  return 'live';
end $$;

-- Edge function check: NammaStay admins may sync / fetch rooms for any connection (they aren't property members)
create or replace function public.cn_admin_check(p_connection uuid) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare c public.cn_connections%rowtype;
begin
  perform public._assert_platform_admin();
  select * into c from public.cn_connections where id = p_connection;
  if not found then raise exception 'Connection not found.' using errcode = 'P0002'; end if;
  return jsonb_build_object('id', c.id, 'property_id', c.property_id, 'ota', c.ota, 'status', c.status);
end $$;

-- ---------------------------------------------------------------- server (connect edge function, service role)
-- Save the Beds24 link: creates/updates the beds24 connection and the setup row
create or replace function public.cn_b24_link_save(p_property uuid, p_b24_property text, p_managed boolean, p_by uuid) returns uuid
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_id uuid; v_pid text := btrim(coalesce(p_b24_property, ''));
begin
  if v_pid !~ '^[0-9]{1,12}$' then raise exception 'The Beds24 property ID is numbers only.'; end if;
  if exists (select 1 from public.cn_connections where ota = 'beds24' and ota_hotel_id = v_pid and property_id <> p_property) then
    raise exception 'This Beds24 property is already linked to another NammaStay property.';
  end if;
  insert into public.cn_connections (property_id, ota, ota_hotel_id, created_by) values (p_property, 'beds24', v_pid, p_by)
  on conflict (property_id, ota) do update set ota_hotel_id = excluded.ota_hotel_id, last_error = null
  returning id into v_id;
  perform public._cn_sync_groups(v_id);
  insert into public.cn_b24_setup (property_id, managed, state, connection_id, b24_property_id, requested_by)
  values (p_property, p_managed, 'linked', v_id, v_pid, p_by)
  on conflict (property_id) do update set
    connection_id = excluded.connection_id, b24_property_id = excluded.b24_property_id,
    managed = case when public.cn_b24_setup.state = 'cancelled' then excluded.managed else public.cn_b24_setup.managed end,
    state = case when public.cn_b24_setup.state in ('requested','paid','cancelled') then 'linked' else public.cn_b24_setup.state end,
    updated_at = now();
  insert into public.cn_log (connection_id, dir, kind, summary) values (v_id, 'info', 'connection', 'Beds24 property ' || v_pid || ' linked');
  return v_id;
end $$;

-- Property name + room types, for creating the Beds24 property / rooms before a connection exists
create or replace function public.cn_b24_propinfo(p_property uuid) returns jsonb
language sql stable security definer set search_path = public, pg_temp as $$
  select jsonb_build_object('name', p.name, 'groups', (select coalesce(jsonb_agg(jsonb_build_object('title', g->>'title', 'units', (g->>'count')::int)), '[]'::jsonb)
                                                         from jsonb_array_elements(public.cx_groups(p.id)) g))
    from public.properties p where p.id = p_property
$$;

-- Fill matches that are still empty (rooms NammaStay just created in Beds24, or same names)
create or replace function public.cn_b24_automap(p_connection uuid, p_maps jsonb) returns int
language plpgsql security definer set search_path = public, pg_temp as $$
declare m jsonb; v_room text; n int := 0;
begin
  for m in select * from jsonb_array_elements(coalesce(p_maps, '[]'::jsonb)) loop
    v_room := nullif(btrim(coalesce(m->>'ota_room_id', '')), '');
    continue when v_room is null or v_room !~ '^[0-9]{1,12}$';
    continue when exists (select 1 from public.cn_room_map where connection_id = p_connection and ota_room_id = v_room);
    update public.cn_room_map set ota_room_id = v_room, ota_rate_id = null
     where connection_id = p_connection and group_key = m->>'group_key' and ota_room_id is null;
    if found then n := n + 1; end if;
  end loop;
  if n > 0 then update public.cn_connections set dirty_at = now(), full_at = null where id = p_connection; end if;
  return n;
end $$;

create or replace function public.cn_secret_get(p_connection uuid) returns jsonb
language sql stable security definer set search_path = public, pg_temp as $$
  select jsonb_build_object('refresh_token', refresh_token, 'access_token', access_token, 'access_expires_at', access_expires_at)
    from public.cn_secrets where connection_id = p_connection
$$;
create or replace function public.cn_secret_set(p_connection uuid, p_refresh text, p_access text, p_expires timestamptz) returns void
language sql security definer set search_path = public, pg_temp as $$
  insert into public.cn_secrets as s (connection_id, refresh_token, access_token, access_expires_at, updated_at)
  values (p_connection, p_refresh, p_access, p_expires, now())
  on conflict (connection_id) do update set refresh_token = coalesce(excluded.refresh_token, s.refresh_token),
     access_token = excluded.access_token, access_expires_at = excluded.access_expires_at, updated_at = now()
$$;

-- Beds24 booking webhook: right connection + secret key?
create or replace function public.cn_b24_hook(p_connection uuid, p_key text) returns boolean
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  update public.cn_b24_setup set last_hook_at = now()
   where connection_id = p_connection and hook_key = coalesce(p_key, '') and char_length(coalesce(p_key, '')) = 64;
  return found;
end $$;

-- Pull cursor for a connection
create or replace function public.cn_b24_conn(p_connection uuid) returns jsonb
language sql stable security definer set search_path = public, pg_temp as $$
  select jsonb_build_object('last_pull_at', last_pull_at, 'b24_property_id', ota_hotel_id) from public.cn_connections where id = p_connection
$$;

-- Which OTA reservations NammaStay already has (id → revision), so adapters can say new vs modified
create or replace function public.cn_res_known(p_connection uuid, p_ids text[]) returns jsonb
language sql stable security definer set search_path = public, pg_temp as $$
  select coalesce(jsonb_object_agg(ota_res_id, coalesce(revision, '')), '{}'::jsonb)
    from public.cn_reservations where connection_id = p_connection and ota_res_id = any (coalesce(p_ids, '{}'))
$$;

-- One sync at a time per connection
create or replace function public.cn_lease(p_connection uuid, p_seconds int default 120) returns boolean
language sql security definer set search_path = public, pg_temp as $$
  with x as (
    insert into public.cn_leases as l (connection_id, until) values (p_connection, now() + make_interval(secs => least(greatest(coalesce(p_seconds, 120), 5), 600)))
    on conflict (connection_id) do update set until = excluded.until where l.until < now()
    returning 1)
  select exists (select 1 from x)
$$;
create or replace function public.cn_release(p_connection uuid) returns void
language sql security definer set search_path = public, pg_temp as $$
  delete from public.cn_leases where connection_id = p_connection
$$;
create or replace function public.cn_is_dirty(p_connection uuid) returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select coalesce((select status = 'live' and (last_push_at is null or dirty_at > last_push_at) from public.cn_connections where id = p_connection), false)
$$;

-- Managed OTA sync unpaid for more than 3 days past the paid date → pause (bookings already made stay)
create or replace function public.cn_b24_expire() returns int
language plpgsql security definer set search_path = public, pg_temp as $$
declare r record; n int := 0;
begin
  for r in select s.property_id, s.connection_id from public.cn_b24_setup s join public.cn_connections c on c.id = s.connection_id
            where s.managed and s.state = 'live' and c.status = 'live' and s.paid_until < current_date - 3 loop
    update public.cn_connections set status = 'paused' where id = r.connection_id;
    insert into public.cn_log (connection_id, dir, kind, summary) values (r.connection_id, 'info', 'status', 'Paused — OTA sync payment overdue');
    insert into public.notifications (property_id, kind, title, body)
    values (r.property_id, 'ota_sync', 'OTA sync paused', 'Your OTA sync payment is overdue, so beds and prices stopped updating on your OTAs. Pay from OTA sync to switch it back on.');
    n := n + 1;
  end loop;
  return n;
end $$;

-- ---------------------------------------------------------------- "something changed — send it now"
-- When a live connection is marked changed, ping the connect function (pg_net), at most once every 10 s.
-- Silently does nothing when pg_net or the settings aren't there; the every-minute cron still catches up.
create or replace function public._cn_kick() returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_url text; v_secret text; v_go boolean;
begin
  if new.status <> 'live' or new.dirty_at is not distinct from old.dirty_at then return new; end if;
  select function_url, cron_secret into v_url, v_secret from public.cn_settings where id = 1;
  if v_url is null or v_secret is null or to_regprocedure('net.http_post(text, jsonb, jsonb, jsonb, integer)') is null then return new; end if;
  with x as (insert into public.cn_kicks as k (connection_id, kicked_at) values (new.id, now())
             on conflict (connection_id) do update set kicked_at = now() where k.kicked_at < now() - interval '10 seconds' returning 1)
  select exists (select 1 from x) into v_go;
  if v_go then
    execute 'select net.http_post(url := $1, body := $2, params := ''{}''::jsonb, headers := $3, timeout_milliseconds := 5000)'
      using v_url, jsonb_build_object('kick', new.id), jsonb_build_object('Content-Type', 'application/json', 'x-cron-secret', v_secret);
  end if;
  return new;
exception when others then
  return new;                                                     -- never block a booking because of the ping
end $$;
drop trigger if exists cn_kick on public.cn_connections;
create trigger cn_kick after update of dirty_at on public.cn_connections for each row execute function public._cn_kick();

-- ---------------------------------------------------------------- permissions
do $$ declare f text; begin
  foreach f in array array[
    'public._b24_status_json(uuid, boolean)', 'public._cn_kick()',
    'public.cn_b24_status(uuid)', 'public.cn_b24_pay(uuid, text)', 'public.cn_b24_owner_step(uuid, text, boolean)', 'public.cn_b24_cancel(uuid)',
    'public.cn_b24_can_link(uuid, boolean)', 'public.cn_b24_queue()', 'public.cn_b24_admin_pay(uuid, text, boolean, text)', 'public.cn_b24_admin_set(uuid, jsonb)',
    'public.cn_b24_admin_map(uuid, jsonb)', 'public.cn_b24_admin_go_live(uuid)', 'public.cn_admin_check(uuid)',
    'public.cn_b24_link_save(uuid, text, boolean, uuid)', 'public.cn_b24_propinfo(uuid)', 'public.cn_b24_automap(uuid, jsonb)', 'public.cn_secret_get(uuid)',
    'public.cn_secret_set(uuid, text, text, timestamptz)', 'public.cn_b24_hook(uuid, text)', 'public.cn_b24_conn(uuid)',
    'public.cn_res_known(uuid, text[])', 'public.cn_lease(uuid, int)', 'public.cn_release(uuid)', 'public.cn_is_dirty(uuid)', 'public.cn_b24_expire()'] loop
    execute format('revoke execute on function %s from public, anon, authenticated', f);
  end loop;
  foreach f in array array[
    'public.cn_b24_status(uuid)', 'public.cn_b24_pay(uuid, text)', 'public.cn_b24_owner_step(uuid, text, boolean)', 'public.cn_b24_cancel(uuid)',
    'public.cn_b24_can_link(uuid, boolean)', 'public.cn_b24_queue()', 'public.cn_b24_admin_pay(uuid, text, boolean, text)', 'public.cn_b24_admin_set(uuid, jsonb)',
    'public.cn_b24_admin_map(uuid, jsonb)', 'public.cn_b24_admin_go_live(uuid)', 'public.cn_admin_check(uuid)'] loop
    execute format('grant execute on function %s to authenticated', f);
  end loop;
  foreach f in array array[
    'public.cn_b24_link_save(uuid, text, boolean, uuid)', 'public.cn_b24_propinfo(uuid)', 'public.cn_b24_automap(uuid, jsonb)', 'public.cn_secret_get(uuid)',
    'public.cn_secret_set(uuid, text, text, timestamptz)', 'public.cn_b24_hook(uuid, text)', 'public.cn_b24_conn(uuid)',
    'public.cn_res_known(uuid, text[])', 'public.cn_lease(uuid, int)', 'public.cn_release(uuid)', 'public.cn_is_dirty(uuid)', 'public.cn_b24_expire()'] loop
    execute format('grant execute on function %s to service_role', f);
  end loop;
end $$;

-- ---------------------------------------------------------------- AFTER RUNNING: settings for the instant ping
-- Replace YOUR-CRON-SECRET, then run this one line (the same CRON_SECRET as the connect function's secret):
--   update public.cn_settings set function_url = 'https://skcqpfyshbxcyyamsgtj.supabase.co/functions/v1/connect', cron_secret = 'YOUR-CRON-SECRET' where id = 1;
-- Price of the OTA sync add-on (GST included, in paise): ₹1,665 = 166500
--   update public.cn_settings set ota_sync_price_paise = 166500 where id = 1;
