-- Tests for 046_connect_beds24.sql. Run on a database that has the full setup + 004 seed + 045 + 046.
-- Prints PASS/FAIL lines; any FAIL or error = problem.
\set ON_ERROR_STOP 1
\pset tuples_only on
\pset format unaligned
create temp table t_ctx (k text primary key, v text);
grant all on t_ctx to authenticated, service_role;
create or replace function pg_temp.ok(c boolean, msg text) returns text language sql as $$ select case when c then 'PASS ' else 'FAIL ' end || msg $$;
create or replace function pg_temp.v(k_ text) returns text language sql as $$ select v from t_ctx where k = k_ $$;
create or replace function pg_temp.err(sql text) returns text language plpgsql as $$
begin execute sql; return null; exception when others then return sqlerrm; end $$;

insert into t_ctx values ('prop', (select id::text from public.properties limit 1));
insert into auth.users (id, email) values ('22222222-2222-2222-2222-222222222222', 'manager@example.com'), ('33333333-3333-3333-3333-333333333333', 'admin@example.com'),
  ('44444444-4444-4444-4444-444444444444', 'stranger@example.com') on conflict do nothing;
insert into public.property_members (property_id, user_id, role) values (pg_temp.v('prop')::uuid, '22222222-2222-2222-2222-222222222222', 'manager') on conflict do nothing;
insert into public.platform_admins (user_id) values ('33333333-3333-3333-3333-333333333333') on conflict do nothing;
update public.platform_settings set upi_id = 'nammastay@okaxis', payee_name = 'NammaStay' where id = 1;

-- ================================================================ owner asks for OTA sync
set role authenticated; select set_config('request.jwt.claim.sub', '11111111-1111-1111-1111-111111111111', false);
select pg_temp.ok((public.cn_b24_status(pg_temp.v('prop')::uuid)->>'price_paise')::int = 166500, 'price is ₹1,665');
select pg_temp.ok(public.cn_b24_status(pg_temp.v('prop')::uuid)->'setup' = 'null'::jsonb, 'nothing set up yet');
select pg_temp.ok(public.cn_b24_status(pg_temp.v('prop')::uuid)->'pay_to'->>'upi_id' = 'nammastay@okaxis', 'owner sees NammaStay''s UPI ID');
select pg_temp.ok(pg_temp.err($$select public.cn_b24_pay('$$ || pg_temp.v('prop') || $$', 'abc')$$) like '%UPI transaction ID%', 'bad UTR rejected');
select pg_temp.ok(public.cn_b24_pay(pg_temp.v('prop')::uuid, ' 4123 4567 8901 ')->'setup'->>'state' = 'requested', 'pay → requested');
select pg_temp.ok(jsonb_array_length(public.cn_b24_status(pg_temp.v('prop')::uuid)->'setup'->'payments') = 1
  and public.cn_b24_status(pg_temp.v('prop')::uuid)->'setup'->'payments'->0->>'utr' = '412345678901', 'UTR saved without spaces, pending');
select pg_temp.ok(pg_temp.err($$select public.cn_b24_pay('$$ || pg_temp.v('prop') || $$', '412345678901')$$) like '%already submitted%', 'same UTR twice rejected');
select pg_temp.ok(public.cn_b24_owner_step(pg_temp.v('prop')::uuid, 'booking', true)->'setup'->'owner_steps' ? 'booking', 'owner ticks Booking.com accepted');
select pg_temp.ok(pg_temp.err($$select public.cn_b24_owner_step('$$ || pg_temp.v('prop') || $$', 'airbnb', true)$$) like '%Unknown OTA%', 'unknown OTA step rejected');
select pg_temp.ok(pg_temp.err($$select public.cn_b24_can_link('$$ || pg_temp.v('prop') || $$')$$) like '%team sets up OTA sync%', 'owner can''t link a managed setup');
select pg_temp.ok(public.cn_b24_status(pg_temp.v('prop')::uuid)->'setup'->>'hook_key' is null, 'owner doesn''t see the webhook key (managed)');

-- manager / stranger limits
select set_config('request.jwt.claim.sub', '22222222-2222-2222-2222-222222222222', false);
select pg_temp.ok(pg_temp.err($$select public.cn_b24_status('$$ || pg_temp.v('prop') || $$')$$) is null, 'manager can view OTA sync');
select pg_temp.ok(pg_temp.err($$select public.cn_b24_pay('$$ || pg_temp.v('prop') || $$', '999999999999')$$) like '%permission%', 'manager cannot pay');
select pg_temp.ok(pg_temp.err($$select public.cn_b24_queue()$$) like '%permission%', 'manager cannot open the setup queue');
select set_config('request.jwt.claim.sub', '44444444-4444-4444-4444-444444444444', false);
select pg_temp.ok(pg_temp.err($$select public.cn_b24_status('$$ || pg_temp.v('prop') || $$')$$) like '%permission%', 'stranger sees nothing');
-- server functions and tables closed to signed-in users
select pg_temp.ok(pg_temp.err($$select public.cn_secret_get(gen_random_uuid())$$) like '%permission denied%', 'cn_secret_get not callable by users');
select pg_temp.ok(pg_temp.err($$select public.cn_b24_link_save(gen_random_uuid(), '1', true, null)$$) like '%permission denied%', 'cn_b24_link_save not callable by users');
select pg_temp.ok(pg_temp.err($$select * from public.cn_secrets$$) like '%permission denied%', 'secrets table closed');
select pg_temp.ok(pg_temp.err($$select * from public.cn_b24_setup$$) like '%permission denied%', 'setup table closed');

-- ================================================================ NammaStay team (platform admin, not a property member)
select set_config('request.jwt.claim.sub', '33333333-3333-3333-3333-333333333333', false);
select pg_temp.ok(jsonb_array_length(public.cn_b24_queue()) = 1 and public.cn_b24_queue()->0->>'state' = 'requested', 'queue shows the request');
select pg_temp.ok((public.cn_b24_queue()->0->>'units')::int = 9 and public.cn_b24_queue()->0->>'owner' = 'owner@example.com', 'queue shows beds and owner');
select pg_temp.ok(pg_temp.err($$select public.cn_b24_admin_go_live('$$ || pg_temp.v('prop') || $$')$$) like '%Confirm the payment%', 'cannot go live unpaid');
select pg_temp.ok(pg_temp.err($$select public.cn_b24_admin_pay('$$ || pg_temp.v('prop') || $$', '000000000000', true)$$) like '%No pending payment%', 'wrong UTR → no pending payment');
select pg_temp.ok((public.cn_b24_admin_pay(pg_temp.v('prop')::uuid, '412345678901', true)->'setup'->>'paid_until')::date = (current_date + interval '1 month')::date, 'approve → paid a month ahead');
select pg_temp.ok(public.cn_b24_queue()->0->>'state' = 'paid', 'state paid');
select pg_temp.ok(public.cn_b24_can_link(pg_temp.v('prop')::uuid) = '{"admin": true, "managed": true}'::jsonb, 'admin may link (managed)');
select pg_temp.ok(pg_temp.err($$select public.cn_b24_can_link('$$ || pg_temp.v('prop') || $$', true)$$) like '%permission%', 'admin who isn''t the owner can''t link as "own account"');
reset role;
select pg_temp.ok(exists (select 1 from public.notifications where property_id = pg_temp.v('prop')::uuid and title = 'OTA sync payment confirmed'), 'owner notified of payment');

-- ================================================================ connect function (service role): link, automap
select pg_temp.ok(pg_temp.err($$select public.cn_b24_link_save('$$ || pg_temp.v('prop') || $$', '12a', true, null)$$) like '%numbers only%', 'Beds24 ID must be digits');
insert into t_ctx values ('conn', public.cn_b24_link_save(pg_temp.v('prop')::uuid, '123456', true, null)::text);
select pg_temp.ok((select state from public.cn_b24_setup where property_id = pg_temp.v('prop')::uuid) = 'linked', 'state linked');
select pg_temp.ok((select count(*) from public.cn_room_map where connection_id = pg_temp.v('conn')::uuid) = 3, 'connection has 3 room types');
select pg_temp.ok(public.cn_b24_propinfo(pg_temp.v('prop')::uuid)->>'name' = 'Social Backpackers Hostel' and jsonb_array_length(public.cn_b24_propinfo(pg_temp.v('prop')::uuid)->'groups') = 3, 'propinfo: name + 3 room types');
select pg_temp.ok(public.cn_b24_automap(pg_temp.v('conn')::uuid, (select jsonb_agg(jsonb_build_object('group_key', group_key, 'ota_room_id', (500 + n)::text))
  from (select group_key, row_number() over (order by title) n from public.cn_room_map where connection_id = pg_temp.v('conn')::uuid) q)) = 3, 'automap fills 3');
select pg_temp.ok(public.cn_b24_automap(pg_temp.v('conn')::uuid, (select jsonb_agg(jsonb_build_object('group_key', group_key, 'ota_room_id', '999'))
  from public.cn_room_map where connection_id = pg_temp.v('conn')::uuid)) = 0, 'automap never overwrites a match');
select public.cn_secret_set(pg_temp.v('conn')::uuid, 'refresh-1', 'access-1', now() + interval '1 hour');
select public.cn_secret_set(pg_temp.v('conn')::uuid, null, 'access-2', now() + interval '1 hour');
select pg_temp.ok(public.cn_secret_get(pg_temp.v('conn')::uuid)->>'refresh_token' = 'refresh-1' and public.cn_secret_get(pg_temp.v('conn')::uuid)->>'access_token' = 'access-2', 'new token keeps the refresh token');

-- ================================================================ team checklist and go live
set role authenticated; select set_config('request.jwt.claim.sub', '33333333-3333-3333-3333-333333333333', false);
select pg_temp.ok(pg_temp.err($$select public.cn_b24_admin_map('$$ || pg_temp.v('conn') || $$', (select jsonb_agg(jsonb_build_object('group_key', m->>'group_key', 'ota_room_id', '777'))
  from jsonb_array_elements(public.cn_b24_queue()->0->'connection'->'maps') m))$$) like '%same Beds24 room%', 'admin map: duplicate room rejected');
select pg_temp.ok(pg_temp.err($$select public.cn_b24_admin_go_live('$$ || pg_temp.v('prop') || $$')$$) like '%Tick at least one OTA%', 'cannot go live before an OTA is ticked');
select pg_temp.ok(pg_temp.err($$select public.cn_b24_admin_set('$$ || pg_temp.v('prop') || $$', '{"otas_linked":{"airbnb":true}}')$$) like '%Unknown OTA%', 'unknown OTA tick rejected');
select pg_temp.ok(public.cn_b24_admin_set(pg_temp.v('prop')::uuid, '{"otas_linked":{"booking":true,"agoda":false}}')->'setup'->'otas_linked' = '{"booking": true}'::jsonb, 'only ticked OTAs kept');
select pg_temp.ok(public.cn_b24_admin_go_live(pg_temp.v('prop')::uuid) = 'live', 'team takes it live');
select pg_temp.ok(public.cn_b24_queue()->0->'connection'->>'status' = 'live' and public.cn_b24_queue()->0->>'state' = 'live', 'connection and setup live');
select pg_temp.ok(length(public.cn_b24_queue()->0->>'hook_key') = 64, 'team sees the 64-character webhook key');
select pg_temp.ok(public.cn_admin_check(pg_temp.v('conn')::uuid)->>'ota' = 'beds24', 'admin passes the function''s connection check');
reset role;
select pg_temp.ok(exists (select 1 from public.notifications where property_id = pg_temp.v('prop')::uuid and title = 'OTA sync is live' and body like '%Booking.com%'), 'owner told it''s live');
select pg_temp.ok(exists (select 1 from jsonb_array_elements(public.cn_due()) d where d->>'id' = pg_temp.v('conn') and (d->>'full')::boolean), 'live Beds24 connection is due a full refresh');

-- ================================================================ webhook key, leases, dirty, known reservations
insert into t_ctx values ('key', (select hook_key from public.cn_b24_setup where property_id = pg_temp.v('prop')::uuid));
select pg_temp.ok(not public.cn_b24_hook(pg_temp.v('conn')::uuid, 'wrong'), 'wrong webhook key refused');
select pg_temp.ok(public.cn_b24_hook(pg_temp.v('conn')::uuid, pg_temp.v('key')), 'right key accepted');
select pg_temp.ok((select last_hook_at is not null from public.cn_b24_setup where property_id = pg_temp.v('prop')::uuid), 'ping time saved');
select pg_temp.ok(public.cn_lease(pg_temp.v('conn')::uuid, 60) and not public.cn_lease(pg_temp.v('conn')::uuid, 60), 'one sync at a time');
select public.cn_release(pg_temp.v('conn')::uuid);
select pg_temp.ok(public.cn_lease(pg_temp.v('conn')::uuid, 60), 'lease free again after release');
select public.cn_release(pg_temp.v('conn')::uuid);
select pg_temp.ok(public.cn_is_dirty(pg_temp.v('conn')::uuid), 'new live connection is dirty (nothing sent yet)');
select pg_temp.ok(public.cn_res_known(pg_temp.v('conn')::uuid, array['X1']) = '{}'::jsonb, 'no known reservations yet');

-- ================================================================ instant ping (pg_net stand-in)
update public.cn_connections set dirty_at = now() + interval '1 second' where id = pg_temp.v('conn')::uuid;
select pg_temp.ok((select count(*) from public.cn_kicks) = 0, 'no settings → no ping, no error');
create table if not exists net.t_calls (url text, body jsonb, headers jsonb, at timestamptz default clock_timestamp());
create or replace function net.http_post(url text, body jsonb default '{}', params jsonb default '{}', headers jsonb default '{}', timeout_milliseconds integer default 1000)
returns bigint language sql as $$ insert into net.t_calls (url, body, headers) values (url, body, headers) returning 1::bigint $$;
update public.cn_settings set function_url = 'https://abc.supabase.co/functions/v1/connect', cron_secret = 'cron-secret-123' where id = 1;
update public.cn_connections set dirty_at = now() + interval '2 seconds' where id = pg_temp.v('conn')::uuid;
select pg_temp.ok((select count(*) from net.t_calls) = 1 and (select body->>'kick' from net.t_calls limit 1) = pg_temp.v('conn')
  and (select headers->>'x-cron-secret' from net.t_calls limit 1) = 'cron-secret-123', 'change → one ping with the connection and cron secret');
update public.cn_connections set dirty_at = now() + interval '3 seconds' where id = pg_temp.v('conn')::uuid;
select pg_temp.ok((select count(*) from net.t_calls) = 1, 'second change within 10 s → no extra ping');
update public.cn_kicks set kicked_at = now() - interval '20 seconds';
update public.cn_connections set dirty_at = now() + interval '4 seconds' where id = pg_temp.v('conn')::uuid;
select pg_temp.ok((select count(*) from net.t_calls) = 2, 'after 10 s → ping again');
update public.cn_kicks set kicked_at = now() - interval '20 seconds';
insert into public.bed_blocks (property_id, bed_id, starts_at, ends_at, reason)
  select pg_temp.v('prop')::uuid, b.id, now() + interval '20 days', now() + interval '21 days', 'maintenance' from public.beds b where b.property_id = pg_temp.v('prop')::uuid limit 1;
select pg_temp.ok((select count(*) from net.t_calls) = 3, 'blocking a bed pings straight away');
update public.cn_settings set function_url = 'https://abc.supabase.co/functions/v1/connect' where id = 1;
drop function net.http_post(text, jsonb, jsonb, jsonb, integer);
create or replace function net.http_post(url text, body jsonb default '{}', params jsonb default '{}', headers jsonb default '{}', timeout_milliseconds integer default 1000)
returns bigint language plpgsql as $$ begin raise exception 'net down'; end $$;
update public.cn_kicks set kicked_at = now() - interval '20 seconds';
select pg_temp.ok(pg_temp.err($$update public.cn_connections set dirty_at = now() + interval '5 seconds' where id = '$$ || pg_temp.v('conn') || $$'$$) is null, 'a failing ping never blocks the change');
drop function net.http_post(text, jsonb, jsonb, jsonb, integer);

-- ================================================================ overdue → paused
update public.cn_b24_setup set paid_until = current_date - 5 where property_id = pg_temp.v('prop')::uuid;
select pg_temp.ok(public.cn_b24_expire() = 1, 'unpaid 5 days → one connection paused');
select pg_temp.ok((select status from public.cn_connections where id = pg_temp.v('conn')::uuid) = 'paused', 'connection status paused');
select pg_temp.ok(public.cn_b24_expire() = 0, 'already paused → nothing more');
select pg_temp.ok(exists (select 1 from public.notifications where property_id = pg_temp.v('prop')::uuid and title = 'OTA sync paused'), 'owner told it''s paused');

-- ================================================================ owner turns it off, then links their own Beds24
set role authenticated; select set_config('request.jwt.claim.sub', '11111111-1111-1111-1111-111111111111', false);
select pg_temp.ok(public.cn_b24_cancel(pg_temp.v('prop')::uuid)->'setup'->>'state' = 'cancelled', 'owner turns OTA sync off');
select pg_temp.ok(public.cn_b24_can_link(pg_temp.v('prop')::uuid) = '{"admin": false, "managed": false}'::jsonb, 'now the owner may link their own Beds24');
select set_config('request.jwt.claim.sub', '33333333-3333-3333-3333-333333333333', false);
select pg_temp.ok(jsonb_array_length(public.cn_b24_queue()) = 0, 'cancelled request leaves the queue');
reset role;
select public.cn_b24_link_save(pg_temp.v('prop')::uuid, '123456', false, null);
set role authenticated; select set_config('request.jwt.claim.sub', '11111111-1111-1111-1111-111111111111', false);
select pg_temp.ok((public.cn_b24_status(pg_temp.v('prop')::uuid)->'setup'->>'managed')::boolean = false
  and length(public.cn_b24_status(pg_temp.v('prop')::uuid)->'setup'->>'hook_key') = 64, 'own account: owner sees the webhook link key');
select pg_temp.ok(pg_temp.err($$select public.cn_b24_pay('$$ || pg_temp.v('prop') || $$', '512345678901')$$) like '%own Beds24 account%', 'own account: nothing to pay NammaStay');
select pg_temp.ok(public.cn_go_live(pg_temp.v('conn')::uuid) = 'live', 'own account: owner goes live like any channel (Beds24 needs no approval)');
reset role;
