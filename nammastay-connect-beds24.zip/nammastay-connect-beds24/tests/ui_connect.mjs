// Browser test (demo mode) of the NammaStay Connect screens: owner card on OTA sync + admin console.
// usage: node ui_connect.mjs http://localhost:PORT outDir
import { chromium } from '/opt/node22/lib/node_modules/playwright/index.mjs';
import fs from 'fs';
const B = process.argv[2]; const OUT = process.argv[3]; fs.mkdirSync(OUT, { recursive: true });
let pass = 0, fail = 0; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); c ? pass++ : fail++; };
const b = await chromium.launch();
for (const [w, tag] of [[1400, 'desk'], [390, 'phone']]) {
  const ctx = await b.newContext({ viewport: { width: w, height: 900 } }); const pg = await ctx.newPage();
  const errs = []; pg.on('pageerror', (e) => errs.push(e.message)); pg.on('console', (m) => { if (m.type() === 'error' && !/fonts\.g|ERR_/.test(m.text())) errs.push(m.text()); });
  await pg.goto(B + '/login.html?demo=1'); await pg.evaluate(() => { localStorage.clear(); localStorage.setItem('ns.demo.on', '1'); localStorage.setItem('ns.demo.kind', 'hostel'); localStorage.setItem('ns.demo.session', 'owner@demo.nammastay.in'); });
  await pg.goto(B + '/ota.html'); await pg.waitForSelector('#cn-card .ns-card', { timeout: 15000 });
  ok(await pg.isVisible('text=NammaStay Connect'), `${tag}: Connect card shows on OTA sync`);
  ok(!(await pg.isVisible('text=Two-way channel manager')), `${tag}: Channex card removed (OTA sync through Beds24 replaces it)`);
  ok(await pg.locator('#cn-card [data-add]').count() === 6, `${tag}: 6 OTAs offered (incl. Test OTA for admin)`);
  await pg.screenshot({ path: `${OUT}/${tag}-1-card.png`, fullPage: false });

  // Booking.com → waiting
  await pg.click('#cn-card [data-add="booking"]'); await pg.fill('#cn-hid', '15376AB'); await pg.click('.ns-modal-foot .ns-btn'); await pg.waitForTimeout(500);
  ok(await pg.isVisible('text=numbers only'), `${tag}: Booking.com ID validated`);
  await pg.fill('#cn-hid', '15376032'); await pg.click('.ns-modal-foot .ns-btn'); await pg.waitForSelector('.ns-modal .cn-map-row');
  ok(await pg.locator('.cn-map-row').count() === 3, `${tag}: matching dialog lists 3 room types`);
  await pg.click('#cn-fetch'); await pg.waitForTimeout(600);
  ok(await pg.isVisible('text=hasn’t approved NammaStay'), `${tag}: fetching rooms from unapproved OTA explains why`);
  const inputs = pg.locator('.cn-map-row [data-room]'); for (let i = 0; i < 3; i++) await inputs.nth(i).fill('BR' + i);
  await pg.screenshot({ path: `${OUT}/${tag}-2-match.png` });
  await pg.click('.ns-modal-foot .ns-btn'); await pg.waitForTimeout(500);
  await pg.click('#cn-card [data-live]'); await pg.waitForTimeout(700);
  ok(await pg.isVisible('text=Waiting for OTA approval'), `${tag}: Booking.com goes to "Waiting for OTA approval"`);

  // Test OTA → live → reservation comes in
  await pg.click('#cn-card [data-add="test"]'); await pg.fill('#cn-hid', 'TEST-001'); await pg.click('.ns-modal-foot .ns-btn'); await pg.waitForSelector('.ns-modal #cn-fetch');
  await pg.click('#cn-fetch'); await pg.waitForSelector('.ns-modal [data-sel]', { timeout: 5000 });
  const sels = pg.locator('.ns-modal [data-sel]'); const n = await sels.count();
  for (let i = 0; i < n; i++) { const opts = await sels.nth(i).locator('option').allTextContents(); await sels.nth(i).selectOption({ index: i + 1 }); }
  await pg.click('.ns-modal-foot .ns-btn'); await pg.waitForTimeout(500);
  const live = pg.locator('#cn-card .cn-conn', { hasText: 'Test OTA' }).locator('[data-live]'); await live.click(); await pg.waitForTimeout(1500);
  ok(await pg.locator('#cn-card .cn-conn', { hasText: 'Test OTA' }).locator('text=Live').count() > 0, `${tag}: Test OTA is Live`);
  ok(await pg.isVisible('text=Ananya Guest'), `${tag}: first sync brought in a Test OTA reservation`);
  await pg.screenshot({ path: `${OUT}/${tag}-3-live.png`, fullPage: true });
  await pg.goto(B + '/bookings.html'); await pg.waitForTimeout(2500);
  ok((await pg.content()).includes('Ananya Guest'), `${tag}: reservation is a NammaStay booking`);

  // admin console
  await pg.goto(B + '/connections.html'); await pg.waitForSelector('.cn-tbl', { timeout: 15000 });
  ok(await pg.locator('.cn-tbl').nth(1).locator('tbody tr').count() === 2, `${tag}: admin console lists 2 connections`);
  await pg.click('[data-ota="booking"]'); await pg.click('.ns-modal-foot .ns-btn'); await pg.waitForTimeout(800);
  ok((await pg.locator('.cn-tbl').nth(1).locator('tbody tr', { hasText: 'Booking.com' }).textContent()).includes('Live'), `${tag}: switching Booking.com on makes the waiting connection live`);
  await pg.click('[data-log]'); await pg.waitForSelector('.cn-log-row'); ok(await pg.locator('.cn-log-row').count() >= 1, `${tag}: message log opens`); await pg.click('.ns-modal-foot .ns-btn-ghost');
  await pg.locator('[data-view]').click(); await pg.waitForSelector('.cn-grid'); ok(await pg.locator('.cn-grid tbody tr').count() === 3, `${tag}: Test OTA view shows 3 rooms`);
  await pg.screenshot({ path: `${OUT}/${tag}-4-otaview.png` }); await pg.click('.ns-modal-foot .ns-btn-ghost');
  await pg.locator('[data-sim]').click(); await pg.waitForSelector('#sim-room'); await pg.click('.ns-modal-foot .ns-btn'); await pg.waitForTimeout(400);
  await pg.locator('.cn-tbl tr', { hasText: 'Test OTA' }).locator('[data-retry]').click(); await pg.waitForTimeout(1200);
  ok(await pg.isVisible('text=1 reservation update'), `${tag}: simulated booking pulled in by "Retry now"`);
  await pg.screenshot({ path: `${OUT}/${tag}-5-console.png`, fullPage: true });
  const over = await pg.evaluate(() => document.documentElement.scrollWidth - innerWidth); ok(over <= 1, `${tag}: no sideways scroll on console (${over}px)`);
  await pg.goto(B + '/ota.html'); await pg.waitForSelector('#cn-card .ns-card');
  const over2 = await pg.evaluate(() => document.documentElement.scrollWidth - innerWidth); ok(over2 <= 1, `${tag}: no sideways scroll on OTA sync (${over2}px)`);
  ok(errs.length === 0, `${tag}: no JS errors ${errs.slice(0, 3).join(' | ')}`);
  await ctx.close();
}
await b.close();
console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
