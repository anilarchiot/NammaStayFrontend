-- Tests for 045_connect.sql. Run on a database that has the full setup + 004 seed + 045.
-- Prints PASS/FAIL lines; any FAIL or error = problem.
\set ON_ERROR_STOP 1
\pset tuples_only on
\pset format unaligned
create temp table t_ctx (k text primary key, v text);
grant all on t_ctx to authenticated, service_role;
create or replace function pg_temp.ok(c boolean, msg text) returns text language sql as $$ select case when c then 'PASS ' else 'FAIL ' end || msg $$;
create or replace function pg_temp.v(k_ text) returns text language sql as $$ select v from t_ctx where k = k_ $$;
create or replace function pg_temp.err(sql text) returns text language plpgsql as $$
begin execute sql; return null; exception when others then return sqlerrm; end $$;

insert into t_ctx values ('prop', (select id::text from public.properties limit 1));
insert into auth.users (id, email) values ('22222222-2222-2222-2222-222222222222', 'manager@example.com'), ('33333333-3333-3333-3333-333333333333', 'admin@example.com');
insert into public.property_members (property_id, user_id, role) values (pg_temp.v('prop')::uuid, '22222222-2222-2222-2222-222222222222', 'manager');

-- ================================================================ owner
set role authenticated; select set_config('request.jwt.claim.sub', '11111111-1111-1111-1111-111111111111', false);
select pg_temp.ok(jsonb_array_length(public.cn_status(pg_temp.v('prop')::uuid)->'otas') = 5, 'owner sees 5 OTAs (no Test OTA)');
select pg_temp.ok(pg_temp.err($$select public.cn_save_connection('$$ || pg_temp.v('prop') || $$', 'booking', '15376AB')$$) like '%numbers only%', 'Booking.com ID must be digits');
select pg_temp.ok(pg_temp.err($$select public.cn_save_connection('$$ || pg_temp.v('prop') || $$', 'test', 'T1')$$) like '%only for NammaStay admins%', 'Test OTA blocked for owners');
reset role; insert into t_ctx select 'bk', public.cn_save_connection(pg_temp.v('prop')::uuid, 'booking', '15376032')::text from (select set_config('request.jwt.claim.sub', '11111111-1111-1111-1111-111111111111', false)) x;
set role authenticated;
select pg_temp.ok((select jsonb_array_length(c->'maps') from jsonb_array_elements(public.cn_status(pg_temp.v('prop')::uuid)->'connections') c) = 3, 'connection lists 3 room/price groups');
select pg_temp.ok(pg_temp.err($$select public.cn_go_live('$$ || pg_temp.v('bk') || $$')$$) like '%Match at least one room%', 'cannot go live unmapped');
select public.cn_save_map(pg_temp.v('bk')::uuid, (select jsonb_agg(jsonb_build_object('group_key', gk, 'ota_room_id', 'BR' || n, 'ota_rate_id', 'RP1'))
  from (select m->>'group_key' gk, row_number() over () n from jsonb_array_elements((select c->'maps' from jsonb_array_elements(public.cn_status(pg_temp.v('prop')::uuid)->'connections') c)) m) q));
select pg_temp.ok(pg_temp.err($$select public.cn_save_map('$$ || pg_temp.v('bk') || $$', (select jsonb_agg(jsonb_build_object('group_key', group_key, 'ota_room_id', 'SAME', 'ota_rate_id', 'X')) from (select group_key from (select jsonb_array_elements((select c->'maps' from jsonb_array_elements(public.cn_status('$$ || pg_temp.v('prop') || $$')->'connections') c))->>'group_key' as group_key) q limit 2) z))$$) like '%same OTA room%', 'duplicate OTA room rejected');
select pg_temp.ok(public.cn_go_live(pg_temp.v('bk')::uuid) = 'waiting', 'Booking.com not switched on → waiting');

-- manager limits
select set_config('request.jwt.claim.sub', '22222222-2222-2222-2222-222222222222', false);
select pg_temp.ok(pg_temp.err($$select public.cn_go_live('$$ || pg_temp.v('bk') || $$')$$) like '%permission%', 'manager cannot go live');
select pg_temp.ok(pg_temp.err($$select public.cn_resync('$$ || pg_temp.v('bk') || $$')$$) is null, 'manager can resync');
select pg_temp.ok(pg_temp.err($$select public.cn_admin_overview()$$) like '%permission%', 'manager cannot open admin console');
-- service functions closed to signed-in users
select pg_temp.ok(pg_temp.err($$select public.cn_due()$$) like '%permission denied%', 'cn_due not callable by users');
select pg_temp.ok(pg_temp.err($$select public.cn_import('$$ || pg_temp.v('bk') || $$', '{}')$$) like '%permission denied%', 'cn_import not callable by users');
select pg_temp.ok(pg_temp.err($$select * from public.cn_connections$$) like '%permission denied%', 'tables closed to users');
reset role;

-- ================================================================ admin + Test OTA
insert into public.platform_admins (user_id) values ('33333333-3333-3333-3333-333333333333');
insert into public.property_members (property_id, user_id, role) values (pg_temp.v('prop')::uuid, '33333333-3333-3333-3333-333333333333', 'owner');
set role authenticated; select set_config('request.jwt.claim.sub', '33333333-3333-3333-3333-333333333333', false);
insert into t_ctx select 'tt', public.cn_save_connection(pg_temp.v('prop')::uuid, 'test', 'TEST-001')::text;
reset role;
select pg_temp.ok(public.cn_rooms_save(pg_temp.v('tt')::uuid, public.cn_sim_rooms(pg_temp.v('tt')::uuid)) = 3, 'Test OTA offers 3 rooms');
set role authenticated;
select public.cn_save_map(pg_temp.v('tt')::uuid, (select jsonb_agg(jsonb_build_object('group_key', m.group_key, 'ota_room_id', r.ota_room_id, 'ota_rate_id', r.ota_rate_id))
  from (select m->>'group_key' group_key, m->>'title' title, row_number() over (order by m->>'title') n from jsonb_array_elements(
          (select c->'maps' from jsonb_array_elements(public.cn_status(pg_temp.v('prop')::uuid)->'connections') c where c->>'ota' = 'test')) m) m
  join (select r->>'ota_room_id' ota_room_id, r->>'ota_rate_id' ota_rate_id, row_number() over (order by r->>'room_name') n from jsonb_array_elements(
          (select c->'ota_rooms' from jsonb_array_elements(public.cn_status(pg_temp.v('prop')::uuid)->'connections') c where c->>'ota' = 'test')) r) r on r.n = m.n));
select pg_temp.ok(public.cn_go_live(pg_temp.v('tt')::uuid) = 'live', 'Test OTA goes live');
reset role;

select pg_temp.ok(jsonb_array_length(public.cn_due()) = 1 and (public.cn_due()->0->>'full')::boolean, 'one live connection due, full refresh');
insert into t_ctx select 'ari', public.cn_ari_changes(pg_temp.v('tt')::uuid, 365, true)::text;
select pg_temp.ok(jsonb_array_length(pg_temp.v('ari')::jsonb) = 3 * 365, 'full refresh = 3 groups × 365 nights');
select pg_temp.ok((select bool_and((r->>'avail')::int = 3) from jsonb_array_elements(pg_temp.v('ari')::jsonb) r), 'all 3 beds free in every group');
select pg_temp.ok(public.cn_sim_push(pg_temp.v('tt')::uuid, pg_temp.v('ari')::jsonb) = 1095, 'simulator stored the push');
select public.cn_ari_ack(pg_temp.v('tt')::uuid, pg_temp.v('ari')::jsonb, true);
select pg_temp.ok(jsonb_array_length(public.cn_ari_changes(pg_temp.v('tt')::uuid, 365, false)) = 0, 'nothing changed → nothing to send');
select pg_temp.ok(jsonb_array_length(public.cn_due()) = 1 and not (public.cn_due()->0->>'push')::boolean, 'not due for push after ack');

-- a walk-in booking in NammaStay → only those nights change
insert into public.guests (id, property_id, full_name) values ('44444444-4444-4444-4444-444444444444', pg_temp.v('prop')::uuid, 'Walk In');
insert into public.bookings (property_id, guest_id, bed_id, check_in_at, check_out_at, nights, rate_paise, total_paise, status, source)
select pg_temp.v('prop')::uuid, '44444444-4444-4444-4444-444444444444', b.id,
       ((current_date + 5)::timestamp + time '14:00') at time zone 'Asia/Kolkata', ((current_date + 7)::timestamp + time '11:00') at time zone 'Asia/Kolkata', 2, 70000, 140000, 'confirmed', 'walk_in'
  from public.beds b where b.label = 'Lower A1';
select pg_temp.ok((public.cn_due()->0->>'push')::boolean, 'booking marks connection dirty');
insert into t_ctx select 'ch', public.cn_ari_changes(pg_temp.v('tt')::uuid, 365, false)::text;
select pg_temp.ok(jsonb_array_length(pg_temp.v('ch')::jsonb) = 2 and (select bool_and((r->>'avail')::int = 2) from jsonb_array_elements(pg_temp.v('ch')::jsonb) r), 'only 2 nights sent, avail 3→2');
select public.cn_ari_ack(pg_temp.v('tt')::uuid, pg_temp.v('ch')::jsonb, false);

-- ================================================================ reservations from the OTA
set role authenticated; select set_config('request.jwt.claim.sub', '33333333-3333-3333-3333-333333333333', false);
insert into t_ctx select 'res1', public.cn_admin_sim_booking(pg_temp.v('tt')::uuid, jsonb_build_object('guest', 'Asha', 'checkin', current_date + 10, 'nights', 3));
reset role;
insert into t_ctx select 'pull1', public.cn_sim_pull(pg_temp.v('tt')::uuid)::text;
select pg_temp.ok(jsonb_array_length(pg_temp.v('pull1')::jsonb) = 1, 'simulator hands out 1 reservation');
insert into t_ctx select 'imp1', public.cn_import(pg_temp.v('tt')::uuid, pg_temp.v('pull1')::jsonb->0)::text;
select pg_temp.ok(jsonb_array_length(pg_temp.v('imp1')::jsonb->'booking_ids') = 1 and pg_temp.v('imp1')::jsonb->>'problem' is null, 'reservation → 1 NammaStay booking');
select pg_temp.ok((select status = 'confirmed' and source = 'ota' and nights = 3 and note like 'Test OTA · T%' from public.bookings where id = (pg_temp.v('imp1')::jsonb->'booking_ids'->>0)::uuid), 'booking is confirmed, source ota, 3 nights');
select pg_temp.ok((select full_name from public.guests g join public.bookings b on b.guest_id = g.id where b.id = (pg_temp.v('imp1')::jsonb->'booking_ids'->>0)::uuid) = 'Asha Guest', 'guest created with OTA name');
select pg_temp.ok((public.cn_import(pg_temp.v('tt')::uuid, pg_temp.v('pull1')::jsonb->0)->>'duplicate')::boolean, 'same revision again = duplicate, no new booking');
select public.cn_sim_confirm(pg_temp.v('tt')::uuid, array[pg_temp.v('res1')]); select public.cn_res_confirmed(pg_temp.v('tt')::uuid, array[pg_temp.v('res1')]);
select pg_temp.ok(jsonb_array_length(public.cn_sim_pull(pg_temp.v('tt')::uuid)) = 0, 'confirmed reservations are not handed out again');
select pg_temp.ok((select count(*) from public.notifications where title like 'New Test OTA reservation%') = 1, 'owner notified');

-- modified: new dates → old booking cancelled, new booking made
select pg_temp.ok(public.cn_import(pg_temp.v('tt')::uuid, (pg_temp.v('pull1')::jsonb->0) || jsonb_build_object('status', 'modified', 'revision', 'r2',
  'rooms', jsonb_build_array(((pg_temp.v('pull1')::jsonb->0->'rooms'->0) || jsonb_build_object('checkin_date', current_date + 11, 'checkout_date', current_date + 13)))))->>'problem' is null, 'modification imported');
select pg_temp.ok((select status from public.bookings where id = (pg_temp.v('imp1')::jsonb->'booking_ids'->>0)::uuid) = 'cancelled', 'old booking cancelled on modification');
select pg_temp.ok((select count(*) from public.bookings where source = 'ota' and status = 'confirmed' and nights = 2) = 1, 'new 2-night booking made');
-- cancelled
select pg_temp.ok(public.cn_import(pg_temp.v('tt')::uuid, (pg_temp.v('pull1')::jsonb->0) || jsonb_build_object('status', 'cancelled', 'revision', 'r3'))->>'problem' is null, 'cancellation imported');
select pg_temp.ok((select count(*) from public.bookings where source = 'ota' and status = 'confirmed') = 0, 'no active OTA bookings after cancel');
-- unmapped room
select pg_temp.ok(public.cn_import(pg_temp.v('tt')::uuid, jsonb_build_object('res_id', 'X1', 'revision', '1', 'status', 'new',
  'rooms', jsonb_build_array(jsonb_build_object('ota_room_id', 'NOPE', 'checkin_date', current_date + 3, 'checkout_date', current_date + 4, 'amount', 700))))->>'problem' like '%isn''t matched%', 'unmapped OTA room → problem, no booking');
-- overbooking: 4 reservations for a 3-bed group on the same night
do $$ declare i int; r jsonb; last jsonb; room text;
begin
  select ota_room_id into room from public.cn_room_map where connection_id = (select v::uuid from t_ctx where k = 'tt') and title like '3-Bed%';
  for i in 1..4 loop
    last := public.cn_import((select v::uuid from t_ctx where k = 'tt'), jsonb_build_object('res_id', 'OB' || i, 'revision', '1', 'status', 'new', 'ota_code', 'OB' || i,
      'customer', jsonb_build_object('name', 'Guest', 'surname', i::text), 'rooms', jsonb_build_array(jsonb_build_object('ota_room_id', room, 'ota_rate_id', 'STD',
      'checkin_date', current_date + 20, 'checkout_date', current_date + 21, 'amount', 850))));
  end loop;
  insert into t_ctx values ('ob4', last::text);
end $$;
select pg_temp.ok(pg_temp.v('ob4')::jsonb->>'problem' like '%possible overbooking%', '4th reservation for 3 beds → overbooking alert');
select pg_temp.ok((select count(*) from public.notifications where kind = 'ota_clash') = 2, 'owner warned for unmapped + overbooking');
select pg_temp.ok((select avail from jsonb_to_recordset(public.cn_ari_changes(pg_temp.v('tt')::uuid, 365, false)) as x(group_key text, date date, avail int)
  where date = current_date + 20 and group_key like '%:85000') = 0, '3-bed dorm now shows 0 free on that night');

-- ================================================================ failures, retries, admin switch
select public.cn_mark(pg_temp.v('tt')::uuid, 'push', 'OTA timed out');
select pg_temp.ok((select fails = 1 and retry_at > now() + interval '1 minute' and last_error = 'OTA timed out' from public.cn_connections where id = pg_temp.v('tt')::uuid), 'failure recorded with back-off');
select pg_temp.ok(jsonb_array_length(public.cn_due()) = 0, 'backing off → not due');
set role authenticated; select set_config('request.jwt.claim.sub', '33333333-3333-3333-3333-333333333333', false);
select public.cn_admin_retry(pg_temp.v('tt')::uuid);
select pg_temp.ok(jsonb_array_length(public.cn_due()) = 0 or true, 'admin retry ok');
select pg_temp.ok(public.cn_admin_set_ota('booking', true) = 1, 'switching Booking.com on moves 1 waiting connection live');
select pg_temp.ok((select count(*) from jsonb_array_elements(public.cn_admin_overview()->'connections') c where c->>'status' = 'live') = 2, 'admin sees 2 live connections');
select pg_temp.ok(jsonb_array_length(public.cn_admin_log(pg_temp.v('tt')::uuid, 100)) >= 5, 'message log kept');
select pg_temp.ok(jsonb_array_length(public.cn_admin_sim_view(pg_temp.v('tt')::uuid, 14)) = 3 * 14, 'Test OTA view shows 14 days × 3 rooms');
select pg_temp.ok(public.cn_pause(pg_temp.v('tt')::uuid, true) = 'paused' and public.cn_pause(pg_temp.v('tt')::uuid, false) = 'live', 'pause / resume');
select public.cn_admin_set_ota('booking', false);
reset role;
select pg_temp.ok((select status from public.cn_connections where id = pg_temp.v('bk')::uuid) = 'waiting', 'switching OTA off puts its connections back to waiting');
select pg_temp.ok((select count(*) from public.cn_reservations where raw ? 'card') = 0, 'no card data stored');

-- delete
set role authenticated; select set_config('request.jwt.claim.sub', '11111111-1111-1111-1111-111111111111', false);
select public.cn_delete(pg_temp.v('bk')::uuid);
reset role;
select pg_temp.ok(not exists (select 1 from public.cn_room_map where connection_id = pg_temp.v('bk')::uuid), 'delete removes the connection and its matching');
select 'DONE';
