// End-to-end test of OTA sync through Beds24 (046): the real connect function (index.ts + adapters.ts) against the
// local test database and a fake Beds24 API V2 server (same calls and shapes the connector uses).
// usage: node e2e_beds24.mjs <dbname>   (database: setup + 004 seed + 045 + 046)
import ts from '/opt/node22/lib/node_modules/typescript/lib/typescript.js';
import fs from 'fs'; import path from 'path'; import http from 'http'; import { execFileSync } from 'child_process';
const DB = process.argv[2]; const FN = new URL('../supabase/functions/connect/', import.meta.url).pathname; const OUT = '/tmp/cn_e2e_b24';
fs.mkdirSync(OUT, { recursive: true });
const tr = (f) => ts.transpileModule(fs.readFileSync(path.join(FN, f), 'utf8'), { compilerOptions: { module: ts.ModuleKind.ES2022, target: ts.ScriptTarget.ES2022 } }).outputText;
fs.writeFileSync(`${OUT}/adapters.mjs`, tr('adapters.ts'));
fs.writeFileSync(`${OUT}/index.mjs`, tr('index.ts').replace('"npm:@supabase/supabase-js@2"', '"./sb.mjs"').replace('"./adapters.ts"', '"./adapters.mjs"'));

// ---------------------------------------------------------------- fake Beds24 API V2
const today = () => new Date().toISOString().slice(0, 10);
const addDays = (d, n) => { const x = new Date(d + 'T00:00:00Z'); x.setUTCDate(x.getUTCDate() + n); return x.toISOString().slice(0, 10); };
const B = { codes: { 'INVITE-OK-123456789': 'acct' }, refresh: 'REFRESH-ACCT', token: null, tokenN: 0, props: [], nextProp: 100001, nextRoom: 200001,
  cal: {}, bookings: [], nextBk: 900001, calendarPosts: 0, fail429: 0, log: [] };
const issue = () => { B.tokenN++; B.token = 'TOKEN-' + B.tokenN; return B.token; };
const send = (res, status, body, headers = {}) => { res.writeHead(status, { 'content-type': 'application/json', ...headers }); res.end(JSON.stringify(body)); };
const server = http.createServer(async (req, res) => {
  let raw = ''; for await (const ch of req) raw += ch;
  const u = new URL(req.url, 'http://x'); const p = u.pathname.replace(/^\/api\/v2/, ''); B.log.push(`${req.method} ${p}${u.search}`);
  if (B.fail429 > 0 && p !== '/authentication/token') { B.fail429--; return send(res, 429, { success: false, error: 'Usage limit exceeded in last 5 minutes' }, { 'x-five-min-limit-resets-in': '120' }); }
  if (p === '/authentication/setup') {
    if (!B.codes[req.headers.code]) return send(res, 401, { success: false, error: 'Invalid invite code' });
    return send(res, 200, { token: issue(), expiresIn: 86400, refreshToken: B.refresh });
  }
  if (p === '/authentication/token') {
    if (req.headers.refreshtoken !== B.refresh) return send(res, 401, { success: false, error: 'Invalid refresh token' });
    return send(res, 200, { token: issue(), expiresIn: 86400 });
  }
  if (req.headers.token !== B.token) return send(res, 401, { success: false, error: 'Token invalid or expired' });
  const body = raw ? JSON.parse(raw) : null;
  if (p === '/properties' && req.method === 'GET') {
    const id = u.searchParams.get('id');
    return send(res, 200, { success: true, data: B.props.filter((x) => !id || String(x.id) === id) });
  }
  if (p === '/properties' && req.method === 'POST') {
    return send(res, 201, body.map((item) => {
      let prop = item.id ? B.props.find((x) => x.id === item.id) : null;
      if (item.id && !prop) return { success: false, errors: [{ message: 'Property not found' }] };
      if (!prop) { prop = { id: B.nextProp++, name: item.name, currency: item.currency, roomTypes: [] }; B.props.push(prop); }
      for (const r of item.roomTypes || []) prop.roomTypes.push({ id: B.nextRoom++, name: r.name, qty: r.qty });
      return { success: true, [item.id ? 'modified' : 'new']: { id: prop.id } };
    }));
  }
  if (p === '/inventory/rooms/calendar' && req.method === 'POST') {
    B.calendarPosts++;
    return send(res, 201, body.map((r) => {
      const room = B.props.flatMap((x) => x.roomTypes).find((x) => x.id === r.roomId);
      if (!room) return { success: false, errors: [{ message: `Room ${r.roomId} not found` }] };
      for (const c of r.calendar) {
        if (c.numAvail > room.qty) return { success: false, errors: [{ message: 'numAvail more than room qty' }] };
        for (let d = c.from; d <= c.to; d = addDays(d, 1)) B.cal[`${r.roomId}|${d}`] = { numAvail: c.numAvail, price1: c.price1, minStay: c.minStay };
      }
      return { success: true, modified: { roomId: r.roomId } };
    }));
  }
  if (p === '/bookings' && req.method === 'GET') {
    const pid = u.searchParams.get('propertyId'); const mod = u.searchParams.get('modifiedFrom'); const dep = u.searchParams.get('departureFrom');
    const list = B.bookings.filter((b) => String(b.propertyId) === pid && (!mod || Date.parse(b.modifiedTime) >= Date.parse(mod)) && (!dep || b.departure >= dep));
    return send(res, 200, { success: true, data: list, pages: { nextPageExists: false, nextPageLink: null } });
  }
  return send(res, 404, { success: false, error: 'Not found ' + p });
});
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const PORT = server.address().port;
const stamp = () => new Date(Date.now() + 1000).toISOString();                       // "just changed"

// ---------------------------------------------------------------- stand-in supabase client (rpc through psql)
const lit = (v) => v === null || v === undefined ? 'null' : Array.isArray(v) && v.length && v.every((x) => typeof x === 'string')   // non-empty string list = text[]; [] = JSON
  ? `'{${v.map((x) => '"' + x.replace(/"/g, '\\"') + '"').join(',')}}'` : `'${(typeof v === 'object' ? JSON.stringify(v) : String(v)).replace(/'/g, "''")}'`;
globalThis.__psql = (sql, uid) => {
  const pre = uid ? `set role authenticated; select set_config('request.jwt.claim.sub', '${uid}', false);` : '';
  try { const out = execFileSync('psql', ['-U', 'postgres', '-p', '5499', '-h', 'localhost', '-d', DB, '-Atq', '-v', 'ON_ERROR_STOP=1', '-f', '-'], { encoding: 'utf8', input: pre + sql + ';', maxBuffer: 64 * 1024 * 1024, stdio: ['pipe', 'pipe', 'pipe'] });
    const lines = out.trim().split('\n'); const last = lines[lines.length - 1] ?? '';
    try { return { data: last === '' ? null : JSON.parse(last), error: null }; } catch { return { data: last, error: null }; }
  } catch (e) { return { data: null, error: { message: String(e.stderr || e.message).replace(/^psql:.*?ERROR:\s*/s, '').split('\n')[0] } }; }
};
globalThis.__lit = lit;
fs.writeFileSync(`${OUT}/sb.mjs`, `export function createClient(url, key, opts) {
  const auth = opts?.global?.headers?.Authorization || ''; const uid = auth.startsWith('Bearer ') ? auth.slice(7) : null;
  return { rpc: async (fn, args = {}) => globalThis.__psql('select public.' + fn + '(' + Object.entries(args).map(([k, v]) => k + ' => ' + globalThis.__lit(v)).join(', ') + ')::text', uid) };
}`);
let handler;
globalThis.Deno = { env: { get: (k) => ({ SUPABASE_URL: 'http://x', SUPABASE_SERVICE_ROLE_KEY: 's', SUPABASE_ANON_KEY: 'a', CRON_SECRET: 'cron123', BEDS24_API: `http://127.0.0.1:${PORT}/api/v2` })[k] }, serve: (h) => { handler = h; } };
await import(`${OUT}/index.mjs`);

const call = async (body, headers = {}, qs = '') => { const r = await handler(new Request('http://x/connect' + qs, { method: 'POST', headers, body: JSON.stringify(body) })); return { status: r.status, body: await r.json() }; };
const q = (sql) => globalThis.__psql(sql).data;
const as = (uid, sql) => globalThis.__psql(sql, uid);
let pass = 0, fail = 0; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); c ? pass++ : fail++; };

const OWNER = '11111111-1111-1111-1111-111111111111', ADMIN = '33333333-3333-3333-3333-333333333333';
const prop = q('select id from properties limit 1');
q(`insert into auth.users (id, email) values ('${ADMIN}', 'admin@example.com') on conflict do nothing`);
q(`insert into platform_admins (user_id) values ('${ADMIN}') on conflict do nothing`);   // NOT a member of the property
q(`update platform_settings set upi_id = 'nammastay@okaxis', payee_name = 'NammaStay' where id = 1`);
const ownerB = { Authorization: 'Bearer ' + OWNER }, adminB = { Authorization: 'Bearer ' + ADMIN }, cron = { 'x-cron-secret': 'cron123' };

// 1. owner turns on OTA sync and pays; NammaStay confirms
as(OWNER, `select public.cn_b24_pay('${prop}', '412345678901')`);
as(ADMIN, `select public.cn_b24_admin_pay('${prop}', '412345678901', true)`);
ok(as(ADMIN, `select public.cn_b24_queue()::text`).data[0].state === 'paid', 'request paid');

// 2. link
let r = await call({ action: 'link', property_id: prop, code: 'INVITE-OK-123456789' }, ownerB);
ok(r.status === 403 && /team sets up/.test(r.body.error), 'owner cannot link a managed setup');
r = await call({ action: 'link', property_id: prop, code: 'WRONG-CODE-0000' }, adminB);
ok(r.status === 400 && /didn’t accept this invite code/.test(r.body.error), 'wrong invite code → clear error');
r = await call({ action: 'link', property_id: prop, code: 'x' }, adminB);
ok(r.status === 400 && /Paste the invite code/.test(r.body.error), 'junk invite code rejected before calling Beds24');
r = await call({ action: 'link', property_id: prop, code: 'INVITE-OK-123456789' }, adminB);
ok(r.status === 200 && r.body.created === 3 && r.body.mapped === 3 && r.body.groups === 3, `admin links: property + ${r.body.created} rooms created, ${r.body.mapped}/${r.body.groups} matched`);
const conn = r.body.connection_id;
ok(B.props.length === 1 && B.props[0].name === 'Social Backpackers Hostel' && B.props[0].currency === 'INR', 'Beds24 property created in INR with the hostel name');
ok(B.props[0].roomTypes.map((x) => `${x.name}:${x.qty}`).sort().join(',') === '3-Bed Dorm - Rs 850:3,6-Bed Mixed Dorm - Rs 600:3,6-Bed Mixed Dorm - Rs 700:3'.split(',').sort().join(',')
  || B.props[0].roomTypes.every((x) => x.qty === 3), 'one Beds24 room per room type, units = beds: ' + B.props[0].roomTypes.map((x) => `${x.name} ×${x.qty}`).join(', '));
ok(q(`select refresh_token = 'REFRESH-ACCT' from cn_secrets where connection_id = '${conn}'`) === 't', 'Beds24 key saved server-side');
const rooms = Object.fromEntries(B.props[0].roomTypes.map((x) => [x.name, x.id]));
const room700 = B.props[0].roomTypes.find((x) => /700/.test(x.name)).id, room600 = B.props[0].roomTypes.find((x) => /600/.test(x.name)).id;
r = await call({ action: 'link', property_id: prop, code: 'INVITE-OK-123456789' }, adminB);
ok(r.status === 200 && r.body.created === 0 && B.props[0].roomTypes.length === 3 && r.body.mapped === 3, 'linking again reuses the property and rooms (no duplicates)');

// 3. before live: sync skipped; admin (not a member) passes the function's check
r = await call({ action: 'sync', connection_id: conn }, adminB);
ok(r.status === 200 && r.body.skipped, 'admin "sync" before go-live is skipped: ' + r.body.reason);
r = await call({ action: 'rooms', connection_id: conn }, adminB);
ok(r.status === 200 && r.body.rooms.length === 3 && /units/.test(r.body.rooms[0].room_name), 'admin "Get rooms" lists 3 Beds24 rooms with units');
r = await call({ action: 'sync', connection_id: conn }, { Authorization: 'Bearer 99999999-9999-9999-9999-999999999999' });
ok(r.status === 403, 'stranger → 403');

// 4. go live → full refresh
as(ADMIN, `select public.cn_b24_admin_set('${prop}', '{"otas_linked":{"booking":true,"agoda":true}}')`);
ok(as(ADMIN, `select public.cn_b24_admin_go_live('${prop}')`).data === 'live', 'team takes it live');
B.calendarPosts = 0;
r = await call({}, cron);
const o1 = r.body.out.find((x) => x.id === conn);
ok(o1 && o1.nights_sent === 1095 && o1.imported === 0, `cron: full refresh, ${o1?.nights_sent} nights`);
ok(B.calendarPosts === 1, `all 3 rooms in ${B.calendarPosts} message (date ranges)`);
const d5 = addDays(today(), 5), d6 = addDays(today(), 6), d7 = addDays(today(), 7);
ok(B.cal[`${room700}|${d5}`]?.numAvail === 3 && B.cal[`${room700}|${d5}`]?.price1 === 700 && B.cal[`${room700}|${d5}`]?.minStay === 1, 'Beds24 shows 3 free at ₹700, min 1 night');
ok(Object.keys(B.cal).length === 1095, 'Beds24 holds 365 nights × 3 rooms');
ok(B.log.some((l) => l.startsWith('GET /bookings') && l.includes('departureFrom=' + today())), 'first read asks for every booking not yet departed');
r = await call({}, cron);
ok(r.body.out.find((x) => x.id === conn).nights_sent === 0, 'next minute: nothing changed, nothing sent');
ok(B.log.filter((l) => l.startsWith('GET /bookings')).pop().includes('modifiedFrom='), 'later reads ask only for changed bookings');

// 5. Booking.com booking via Beds24 → webhook → NammaStay booking + availability back out
const bk1 = { id: B.nextBk++, masterId: null, propertyId: B.props[0].id, roomId: room700, status: 'new', arrival: d5, departure: d7, numAdult: 1,
  firstName: 'Arjun', lastName: 'Kumar', email: 'arjun@example.com', mobile: '+91 98400 12345', country2: 'IN', price: 1400, apiReference: 'BDC-4455', referer: 'Booking.com', modifiedTime: stamp() };
B.bookings.push(bk1);
const key = q(`select hook_key from cn_b24_setup where property_id = '${prop}'`);
r = await call({}, {}, `?hook=beds24&c=${conn}&k=wrong`);
ok(r.status === 403, 'webhook with a wrong key → 403');
r = await call({}, {}, `?hook=beds24&c=not-a-uuid&k=${key}`);
ok(r.status === 404, 'webhook with a bad connection → 404');
r = await call({}, {}, `?hook=beds24&c=${conn}&k=${key}`);
ok(r.status === 200 && r.body.imported === 1 && r.body.problems.length === 0, 'webhook: Booking.com reservation imported');
ok(r.body.nights_sent === 2 && B.cal[`${room700}|${d5}`].numAvail === 2 && B.cal[`${room700}|${d6}`].numAvail === 2, 'and the 2 nights went back to Beds24 with one bed fewer');
ok(q(`select count(*) from bookings where source = 'ota' and status = 'confirmed' and note like '%BDC-4455%' and note like '%Via Booking.com%'`) === 1, 'NammaStay booking: code BDC-4455, via Booking.com');
ok(q(`select phone from guests where full_name = 'Arjun Kumar'`) === '+919840012345', 'guest saved with a clean phone number');
ok(q(`select count(*) from notifications where title = 'New Beds24 reservation'`) === 1, 'owner notified');
r = await call({}, {}, `?hook=beds24&c=${conn}&k=${key}`);
ok(r.body.imported === 0, 'same webhook again: nothing new');

// 6. guest changes dates → next minute
Object.assign(bk1, { arrival: d6, departure: addDays(today(), 8), price: 1400, modifiedTime: stamp() });
r = await call({}, cron);
let o = r.body.out.find((x) => x.id === conn);
ok(o.imported === 1, 'date change imported (modified)');
ok(q(`select count(*) from bookings where note like '%BDC-4455%' and status = 'cancelled'`) === 1 && q(`select count(*) from bookings where note like '%BDC-4455%' and status = 'confirmed'`) === 1, 'old dates cancelled, new dates booked');
ok(B.cal[`${room700}|${d5}`].numAvail === 3 && B.cal[`${room700}|${addDays(today(), 7)}`].numAvail === 2, 'Beds24: day 5 free again, day 7 taken');

// 7. guest cancels → instant ping from the database (kick) picks it up
Object.assign(bk1, { status: 'cancelled', modifiedTime: stamp() });
r = await call({ kick: conn }, cron);
ok(r.status === 200 && r.body.imported === 1, 'kick: cancellation imported');
ok(q(`select count(*) from bookings where note like '%BDC-4455%' and status = 'confirmed'`) === 0, 'NammaStay booking cancelled');
ok(B.cal[`${room700}|${d6}`].numAvail === 3 && B.cal[`${room700}|${d7}`].numAvail === 3, 'Beds24: beds back on sale');

// 8. group booking (2 rooms), an unmatched room, and an unconfirmed request
const g1 = { id: B.nextBk++, propertyId: B.props[0].id, roomId: room600, status: 'confirmed', arrival: addDays(today(), 10), departure: addDays(today(), 12), numAdult: 1,
  firstName: 'Neha', lastName: 'Rao', email: 'neha@example.com', price: 1200, apiReference: 'AG-77', referer: 'Agoda', modifiedTime: stamp() };
const g2 = { ...g1, id: B.nextBk++, masterId: g1.id, roomId: room700, price: 1400 };
const bad = { ...g1, id: B.nextBk++, masterId: null, roomId: 999999, apiReference: 'AG-88', firstName: 'Sanjay', email: 'sanjay@example.com' };
const reqst = { ...g1, id: B.nextBk++, masterId: null, status: 'request', apiReference: 'REQ-1', firstName: 'Rahul', email: 'rahul@example.com' };
B.bookings.push(g1, g2, bad, reqst);
r = await call({}, {}, `?hook=beds24&c=${conn}&k=${key}`);
ok(r.body.imported === 2, `group booking + unmatched room imported as 2 reservations (${r.body.imported})`);
ok(q(`select count(*) from bookings where note like '%AG-77%' and status = 'confirmed'`) === 2, 'group booking → 2 NammaStay bookings (one per bed)');
ok(r.body.problems.length === 1 && /isn['’]t matched/.test(r.body.problems[0]), 'unmatched Beds24 room → flagged for the owner ' + JSON.stringify(r.body.problems));
ok(q(`select count(*) from cn_reservations where ota_code = 'REQ-1'`) === 0, 'unconfirmed request ignored');

// 9. NammaStay-side change → pushed (kick), only the changed nights
q(`insert into bed_blocks (property_id, bed_id, starts_at, ends_at, reason) select '${prop}', id, ('${addDays(today(), 20)}'::date + time '14:00') at time zone 'Asia/Kolkata', ('${addDays(today(), 21)}'::date + time '11:00') at time zone 'Asia/Kolkata', 'maintenance' from beds where id = (select bed_ids[1] from cn_room_map where connection_id = '${conn}' and ota_room_id = '${room600}')`);
r = await call({ kick: conn }, cron);
ok(r.body.nights_sent === 1 && B.cal[`${room600}|${addDays(today(), 20)}`].numAvail === 2, 'blocked bed → 1 night sent, Beds24 shows 2 free ' + JSON.stringify(r.body) + JSON.stringify(B.cal[`${room600}|${addDays(today(), 20)}`]));

// 10. token expiry → renewed with the saved key
q(`update cn_secrets set access_expires_at = now() - interval '1 minute' where connection_id = '${conn}'`);
const before = q(`select access_token from cn_secrets where connection_id = '${conn}'`);
r = await call({ action: 'sync', connection_id: conn }, ownerB);
ok(r.status === 200 && q(`select access_token from cn_secrets where connection_id = '${conn}'`) !== before, 'expired token renewed with the refresh key (owner "Sync now") ' + JSON.stringify(r));

// 11. usage limit → back-off, then recovery
q(`update cn_connections set dirty_at = now() where id = '${conn}'`); q(`delete from cn_ari_sent where connection_id = '${conn}' and day = current_date + 30`);
B.fail429 = 5;
r = await call({}, cron);
o = r.body.out.find((x) => x.id === conn);
ok(o && /usage limit/.test(o.error), 'Beds24 429 → clear "usage limit" error ' + JSON.stringify(o));
ok(q(`select fails >= 1 and retry_at > now() from cn_connections where id = '${conn}'`) === 't', 'connection backs off');
B.fail429 = 0; as(ADMIN, `select public.cn_admin_retry('${conn}')`);
r = await call({}, cron);
ok(!r.body.out.find((x) => x.id === conn).error, 'after the limit resets, sync works again');

// 12. one run at a time
q(`insert into cn_leases (connection_id, until) values ('${conn}', now() + interval '1 minute') on conflict (connection_id) do update set until = excluded.until`);
r = await call({ kick: conn }, cron);
ok(r.body.skipped && /already running/.test(r.body.reason), 'a second run while one is busy is skipped');
q(`delete from cn_leases where connection_id = '${conn}'`);

// 13. payment overdue → paused by the cron
q(`update cn_b24_setup set paid_until = current_date - 4 where property_id = '${prop}'`);
r = await call({}, cron);
ok(!r.body.out.some((x) => x.id === conn) && q(`select status from cn_connections where id = '${conn}'`) === 'paused', 'unpaid past grace → paused by the cron, not synced');

// 14. owner turns OTA sync off, then links their own Beds24 (no fee, owner goes live)
as(OWNER, `select public.cn_b24_cancel('${prop}')`);
r = await call({ action: 'link', property_id: prop, code: 'INVITE-OK-123456789', own: true }, ownerB);
ok(r.status === 200 && r.body.connection_id === conn, 'owner links their own Beds24 (same connection reused)');
ok(q(`select managed::text || '/' || state from cn_b24_setup where property_id = '${prop}'`) === 'false/linked', 'setup is now "own account", linked');
r = await call({ action: 'link', property_id: prop, code: 'INVITE-OK-123456789' }, ownerB);
ok(r.status === 200, 'owner (own account) may re-link without the flag too');

server.close();
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
