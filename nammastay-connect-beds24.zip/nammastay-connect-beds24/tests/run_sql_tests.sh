#!/bin/bash
# usage: tests/run_sql_tests.sh — fresh DBs from the cnbase template (setup + 004 seed), runs 045 and 046 SQL tests
cd "$(dirname "$0")/.." || exit 1
P="psql -U postgres -p 5499 -h localhost -q"
run() { local db=$1; shift; $P -c "drop database if exists $db" -c "create database $db template cnbase" 2>&1 | grep -v NOTICE
  for f in "$@"; do $P -d $db -v ON_ERROR_STOP=1 -f $f 2>&1 | grep -v NOTICE | grep . && { echo "APPLY FAILED: $f"; return 1; }; done; return 0; }
run cnt45 supabase/sql/updates/045_connect.sql && $P -d cnt45 -f tests/test_045_connect.sql 2>&1 | grep -E "^(PASS|FAIL)|ERROR" > /tmp/t45.out
run cnt46 supabase/sql/updates/045_connect.sql supabase/sql/updates/046_connect_beds24.sql && $P -d cnt46 -f tests/test_046_connect_beds24.sql 2>&1 | grep -E "^(PASS|FAIL)|ERROR" > /tmp/t46.out
echo "045: $(grep -c ^PASS /tmp/t45.out) pass, $(grep -c -v ^PASS /tmp/t45.out) fail/error"; grep -v ^PASS /tmp/t45.out
echo "046: $(grep -c ^PASS /tmp/t46.out) pass, $(grep -c -v ^PASS /tmp/t46.out) fail/error"; grep -v ^PASS /tmp/t46.out
