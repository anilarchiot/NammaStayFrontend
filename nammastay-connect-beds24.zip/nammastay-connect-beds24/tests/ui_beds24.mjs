// Browser test (demo mode) of OTA sync through Beds24 (046): owner card (offer → pay → accept steps → live),
// admin setup queue (confirm payment → link → tick OTAs → go live), own-account link. Desktop + phone.
// usage: node ui_beds24.mjs http://localhost:PORT outDir
import { chromium } from '/opt/node22/lib/node_modules/playwright/index.mjs';
import fs from 'fs';
const B = process.argv[2]; const OUT = process.argv[3]; fs.mkdirSync(OUT, { recursive: true });
let pass = 0, fail = 0; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); c ? pass++ : fail++; };
const b = await chromium.launch();
for (const [w, tag] of [[1400, 'desk'], [390, 'phone']]) {
  const ctx = await b.newContext({ viewport: { width: w, height: 900 } }); const pg = await ctx.newPage();
  const errs = []; pg.on('pageerror', (e) => errs.push(e.message)); pg.on('console', (m) => { if (m.type() === 'error' && !/fonts\.g|ERR_/.test(m.text())) errs.push(m.text()); });
  const over = async (what) => { const o = await pg.evaluate(() => document.documentElement.scrollWidth - innerWidth); ok(o <= 1, `${tag}: no sideways scroll on ${what} (${o}px)`); };
  await pg.goto(B + '/login.html?demo=1'); await pg.evaluate(() => { localStorage.clear(); localStorage.setItem('ns.demo.on', '1'); localStorage.setItem('ns.demo.kind', 'hostel'); localStorage.setItem('ns.demo.session', 'owner@demo.nammastay.in'); });

  // ---- owner: offer
  await pg.goto(B + '/ota.html'); await pg.waitForSelector('#cn-card .cn-sync', { timeout: 15000 });
  ok(await pg.isVisible('text=always in step'), `${tag}: OTA sync offer shows`);
  ok((await pg.locator('#cn-card .cn-sync').textContent()).includes('₹1,665'), `${tag}: price ₹1,665 shown`);
  ok(await pg.locator('#cn-card [data-add="beds24"]').count() === 0 && await pg.locator('#cn-card [data-add]').count() === 6, `${tag}: Beds24 not in the plain OTA tiles (6 tiles stay)`);
  await pg.locator('#cn-card .cn-sync').screenshot({ path: `${OUT}/${tag}-b1-offer.png` });
  await over('OTA sync offer');
  await pg.click('[data-b24-how]'); await pg.waitForSelector('.ns-modal'); ok(await pg.isVisible('.ns-modal >> text=Accept Beds24'), `${tag}: "How it works" explains the steps`); await pg.click('.ns-modal-foot .ns-btn-ghost');

  // ---- owner: pay
  await pg.click('#cn-card [data-b24-pay]'); await pg.waitForSelector('#cn-utr');
  ok(await pg.isVisible('.ns-modal >> text=nammastay@okaxis'), `${tag}: pay dialog shows NammaStay's UPI ID`);
  await pg.fill('#cn-utr', 'abc'); await pg.click('.ns-modal-foot .ns-btn'); await pg.waitForTimeout(400);
  ok(await pg.isVisible('.ns-modal >> text=UPI transaction ID (UTR) from your payment screen'), `${tag}: bad UTR explained`);
  await pg.screenshot({ path: `${OUT}/${tag}-b2-pay.png` });
  await pg.fill('#cn-utr', '412345678901'); await pg.click('.ns-modal-foot .ns-btn'); await pg.waitForSelector('#cn-card .cn-steps', { timeout: 5000 });
  ok(await pg.isVisible('#cn-card >> text=Payment submitted'), `${tag}: steps show "payment submitted"`);
  await pg.click('#cn-card [data-b24-step="booking"][data-done="1"]'); await pg.waitForTimeout(500);
  await pg.click('#cn-card [data-b24-step="agoda"][data-done="1"]'); await pg.waitForTimeout(500);
  ok(await pg.locator('#cn-card .cn-acc.done').count() === 2, `${tag}: owner ticked Booking.com and Agoda`);
  ok(await pg.isVisible('#cn-card [data-b24-copymsg]'), `${tag}: Goibibo message ready to copy`);
  await pg.locator('#cn-card .cn-sync').screenshot({ path: `${OUT}/${tag}-b3-steps.png` });
  await over('setup steps');

  // ---- NammaStay team: admin setup queue
  await pg.goto(B + '/connections.html'); await pg.waitForSelector('[data-setup]', { timeout: 15000 });
  ok(await pg.isVisible('text=1 payment to confirm'), `${tag}: queue shows the payment to confirm`);
  await pg.screenshot({ path: `${OUT}/${tag}-b4-queue.png`, fullPage: false });
  await over('admin queue');
  await pg.click('[data-setup]'); await pg.waitForSelector('.ns-modal [data-pay]');
  await pg.click('.ns-modal [data-pay][data-ok="1"]'); await pg.waitForSelector('.ns-modal >> text=Paid until', { timeout: 5000 });
  ok(await pg.isVisible('.ns-modal >> text=Confirmed'), `${tag}: payment confirmed`);
  await pg.fill('#sq-code', 'x'); await pg.click('#sq-link'); await pg.waitForTimeout(500);
  ok(await pg.isVisible('text=Paste the invite code'), `${tag}: junk invite code rejected`);
  await pg.fill('#sq-code', 'DEMO-INVITE-123456'); await pg.click('#sq-link'); await pg.waitForSelector('.ns-modal >> text=Linked — Beds24 property', { timeout: 5000 });
  ok(await pg.isVisible('.ns-modal >> text=3 of 3 room types matched'), `${tag}: linked, 3 of 3 room types matched`);
  await pg.click('#sq-map'); await pg.waitForSelector('.ns-modal [data-g] select'); ok(await pg.locator('.ns-modal [data-g]').count() === 3, `${tag}: admin can match rooms`);
  await pg.click('.ns-modal-foot .ns-btn'); await pg.waitForSelector('#sq-otas', { timeout: 5000 });
  await pg.click('.ns-modal-foot .ns-btn'); await pg.waitForTimeout(500);
  ok(await pg.isVisible('text=Tick at least one OTA'), `${tag}: can't go live before ticking an OTA`);
  await pg.check('.ns-modal [data-sq-ota="booking"]'); await pg.check('.ns-modal [data-sq-ota="agoda"]'); await pg.click('#sq-otas'); await pg.waitForTimeout(600);
  await pg.screenshot({ path: `${OUT}/${tag}-b5-setup.png`, fullPage: false });
  await pg.click('.ns-modal-foot .ns-btn'); await pg.waitForTimeout(1200);
  ok((await pg.locator('.cn-tbl tbody tr', { hasText: 'Social' }).first().textContent()).includes('Live'), `${tag}: queue row shows Live`);

  // ---- owner: live
  await pg.goto(B + '/ota.html'); await pg.waitForSelector('#cn-card .cn-list', { timeout: 15000 });
  const list = await pg.locator('#cn-card .cn-list').textContent();
  ok(/Booking\.comLive/.test(list.replace(/\s/g, '')) && /AgodaLive/.test(list.replace(/\s/g, '')), `${tag}: Booking.com and Agoda live`);
  ok(/GoibiboNotconnected/.test(list.replace(/\s/g, '')), `${tag}: Goibibo not connected yet`);
  await pg.click('#cn-card .cn-sync [data-sync]'); await pg.waitForTimeout(1500);
  ok(await pg.isVisible('#cn-card >> text=Ananya Guest'), `${tag}: first sync brought in a reservation`);
  ok(await pg.isVisible('#cn-card >> text=paid until'), `${tag}: billing line with paid-until date`);
  { const t = await pg.locator('#cn-card .cn-sync').textContent(); ok(!/undefined|NaN|null/.test(t) && t.includes('3 of 3 room types matched'), `${tag}: live card shows 3 of 3 room types matched (no blanks)`); }
  await pg.locator('#cn-card .cn-sync').screenshot({ path: `${OUT}/${tag}-b6-live.png` });
  await over('OTA sync live');

  // ---- owner: turn off, then link own Beds24
  await pg.click('#cn-card [data-b24-off]'); await pg.click('.ns-modal-foot .ns-btn-danger'); await pg.waitForSelector('#cn-card >> text=always in step', { timeout: 5000 });
  ok(true, `${tag}: turned off → offer again`);
  await pg.click('#cn-card [data-b24-own]'); await pg.fill('#b24-code', 'MY-OWN-INVITE-1234'); await pg.click('.ns-modal-foot .ns-btn'); await pg.waitForSelector('#cn-card .cn-hook', { timeout: 5000 });
  ok(await pg.isVisible('#cn-card >> text=Instant bookings from your Beds24'), `${tag}: own account shows its webhook link`);
  ok((await pg.locator('#cn-card .cn-hook input').inputValue()).includes('hook=beds24'), `${tag}: webhook link is the connect function's Beds24 hook`);
  await pg.screenshot({ path: `${OUT}/${tag}-b7-own.png`, fullPage: true });
  await over('own account');
  ok(errs.length === 0, `${tag}: no JS errors ${errs.slice(0, 3).join(' | ')}`);
  await ctx.close();
}
await b.close();
console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
