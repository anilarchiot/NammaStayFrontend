// End-to-end test of supabase/functions/connect (real code) against the local test database.
// The Supabase client is replaced by a tiny stand-in that runs each rpc() through psql:
// service-role calls run as the database owner; signed-in calls run as `authenticated` with that user id.
// usage: node e2e_connect_function.mjs <dbname>
import ts from '/opt/node22/lib/node_modules/typescript/lib/typescript.js';
import fs from 'fs'; import path from 'path'; import { execFileSync } from 'child_process';
const DB = process.argv[2]; const FN = new URL('../supabase/functions/connect/', import.meta.url).pathname; const OUT = '/tmp/cn_e2e';
fs.mkdirSync(OUT, { recursive: true });
const tr = (f) => ts.transpileModule(fs.readFileSync(path.join(FN, f), 'utf8'), { compilerOptions: { module: ts.ModuleKind.ES2022, target: ts.ScriptTarget.ES2022 } }).outputText;
fs.writeFileSync(`${OUT}/adapters.mjs`, tr('adapters.ts'));
fs.writeFileSync(`${OUT}/index.mjs`, tr('index.ts').replace('"npm:@supabase/supabase-js@2"', '"./sb.mjs"').replace('"./adapters.ts"', '"./adapters.mjs"'));

// ---- stand-in supabase client
const lit = (v) => v === null || v === undefined ? 'null' : Array.isArray(v) && v.every((x) => typeof x === 'string')
  ? `'{${v.map((x) => '"' + x.replace(/"/g, '\\"') + '"').join(',')}}'` : `'${(typeof v === 'object' ? JSON.stringify(v) : String(v)).replace(/'/g, "''")}'`;
globalThis.__psql = (sql, uid) => {
  const pre = uid ? `set role authenticated; select set_config('request.jwt.claim.sub', '${uid}', false);` : '';
  try { const out = execFileSync('psql', ['-U', 'postgres', '-p', '5499', '-h', 'localhost', '-d', DB, '-Atq', '-v', 'ON_ERROR_STOP=1', '-f', '-'], { encoding: 'utf8', input: pre + sql + ';', maxBuffer: 64 * 1024 * 1024, stdio: ['pipe', 'pipe', 'pipe'] });
    const lines = out.trim().split('\n'); const last = lines[lines.length - 1] ?? '';
    try { return { data: last === '' ? null : JSON.parse(last), error: null }; } catch { return { data: last, error: null }; }
  } catch (e) { return { data: null, error: { message: String(e.stderr || e.message).replace(/^psql:.*?ERROR:\s*/s, '').split('\n')[0] } }; }
};
fs.writeFileSync(`${OUT}/sb.mjs`, `export function createClient(url, key, opts) {
  const auth = opts?.global?.headers?.Authorization || ''; const uid = auth.startsWith('Bearer ') ? auth.slice(7) : null;
  return { rpc: async (fn, args = {}) => globalThis.__psql('select public.' + fn + '(' + Object.entries(args).map(([k, v]) => k + ' => ' + globalThis.__lit(v)).join(', ') + ')::text', uid) };
}`);
globalThis.__lit = lit;
let handler;
globalThis.Deno = { env: { get: (k) => ({ SUPABASE_URL: 'http://x', SUPABASE_SERVICE_ROLE_KEY: 's', SUPABASE_ANON_KEY: 'a', CRON_SECRET: 'cron123' })[k] }, serve: (h) => { handler = h; } };
await import(`${OUT}/index.mjs`);

const call = async (body, headers) => { const r = await handler(new Request('http://x/connect', { method: 'POST', headers, body: JSON.stringify(body) })); return { status: r.status, body: await r.json() }; };
const q = (sql) => globalThis.__psql(sql).data;
let pass = 0, fail = 0; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); c ? pass++ : fail++; };

const OWNER = '11111111-1111-1111-1111-111111111111', ADMIN = '33333333-3333-3333-3333-333333333333';
const prop = q('select id from properties limit 1');
q(`insert into auth.users (id, email) values ('${ADMIN}', 'admin@example.com') on conflict do nothing`);
q(`insert into platform_admins (user_id) values ('${ADMIN}') on conflict do nothing`);
q(`insert into property_members (property_id, user_id, role) values ('${prop}', '${ADMIN}', 'owner') on conflict do nothing`);
const conn = globalThis.__psql(`select public.cn_save_connection('${prop}', 'test', 'TEST-001')::text`, ADMIN).data;
ok(/^[0-9a-f-]{36}$/.test(conn), 'admin created a Test OTA connection');

let r = await call({ action: 'rooms', connection_id: conn }, { Authorization: 'Bearer ' + OWNER });
ok(r.status === 200 && r.body.rooms.length === 3, `rooms action → ${r.body.rooms?.length} OTA rooms`);
r = await call({ action: 'rooms', connection_id: conn }, {});
ok(r.status === 401, 'no sign-in → 401');
r = await call({ action: 'sync', connection_id: conn }, { Authorization: 'Bearer 99999999-9999-9999-9999-999999999999' });
ok(r.status === 403, 'stranger → 403');
r = await call({ action: 'sync', connection_id: conn }, { Authorization: 'Bearer ' + OWNER });
ok(r.status === 200 && r.body.skipped, 'sync before go-live is skipped: ' + r.body.reason);

// match rooms by name order and go live (as the owner would in the screen)
const st = globalThis.__psql(`select public.cn_status('${prop}')::text`, OWNER).data;
const c0 = st.connections.find((c) => c.ota === 'test');
const rooms = [...c0.ota_rooms].sort((a, b) => a.room_name.localeCompare(b.room_name)); const maps = [...c0.maps].sort((a, b) => a.title.localeCompare(b.title));
globalThis.__psql(`select public.cn_save_map('${conn}', ${lit(maps.map((m, i) => ({ group_key: m.group_key, ota_room_id: rooms[i].ota_room_id, ota_rate_id: rooms[i].ota_rate_id })))})::text`, OWNER);
ok(globalThis.__psql(`select public.cn_go_live('${conn}')`, ADMIN).data === 'live', 'connection live');

// cron run: full refresh
r = await call({}, { 'x-cron-secret': 'cron123' });
ok(r.status === 200 && r.body.connections === 1 && r.body.out[0].nights_sent === 1095, `cron: full refresh sent ${r.body.out?.[0]?.nights_sent} nights`);
ok(q(`select count(*) from cn_sim_ari where connection_id = '${conn}'`) === 1095, 'Test OTA now holds 1095 nights');
r = await call({}, { 'x-cron-secret': 'cron123' });
ok(r.body.out[0].nights_sent === 0, 'second cron: nothing changed, nothing sent');
r = await call({}, { 'x-cron-secret': 'wrong' });
ok(r.status === 401, 'wrong cron secret treated as not signed in');

// guest books on the "OTA" → next cron imports it, confirms it, and sends the new availability
const resId = globalThis.__psql(`select public.cn_admin_sim_booking('${conn}', '{"guest":"Ravi","nights":2}')`, ADMIN).data;
r = await call({}, { 'x-cron-secret': 'cron123' });
ok(r.body.out[0].imported === 1 && r.body.out[0].problems.length === 0, 'cron imported the OTA reservation');
ok(r.body.out[0].nights_sent === 2, `…and sent the 2 changed nights back (${r.body.out[0].nights_sent})`);
ok(q(`select count(*) from bookings where source = 'ota' and status = 'confirmed' and note like '%${resId}%'`) === 1, 'NammaStay booking exists');
ok(q(`select confirmed_at is not null from cn_sim_res where payload->>'res_id' = '${resId}' order by id desc limit 1`) === 't', 'reservation confirmed back to the OTA');
ok(q(`select confirmed_at is not null from cn_reservations where ota_res_id = '${resId}'`) === 't', 'marked confirmed in NammaStay');

// owner cancels nothing; OTA cancels → booking cancelled, availability restored
globalThis.__psql(`select public.cn_admin_sim_booking('${conn}', '{"cancel":"${resId}"}')`, ADMIN);
r = await call({ action: 'sync', connection_id: conn }, { Authorization: 'Bearer ' + OWNER });
ok(r.status === 200 && r.body.imported === 1 && r.body.nights_sent === 2, 'owner "Sync now": cancellation in, 2 nights reopened');
ok(q(`select count(*) from bookings where source = 'ota' and status = 'confirmed'`) === 0, 'OTA booking cancelled in NammaStay');

// failure: OTA unreachable → back-off, log, error shown
q(`update cn_otas set enabled = true where ota = 'booking'`);
const bk = globalThis.__psql(`select public.cn_save_connection('${prop}', 'booking', '15376032')::text`, OWNER).data;
globalThis.__psql(`select public.cn_save_map('${bk}', ${lit(maps.map((m, i) => ({ group_key: m.group_key, ota_room_id: 'B' + i, ota_rate_id: 'R1' })))})::text`, OWNER);
globalThis.__psql(`select public.cn_go_live('${bk}')`, OWNER);
r = await call({}, { 'x-cron-secret': 'cron123' });
const bo = r.body.out.find((x) => x.id === bk);
ok(bo && /hasn’t approved NammaStay/.test(bo.error), 'Booking.com without partner credentials → clear error, no fake success');
ok(q(`select fails = 1 and retry_at > now() from cn_connections where id = '${bk}'`) === 't', 'failure backs off');
r = await call({}, { 'x-cron-secret': 'cron123' });
ok(!r.body.out.some((x) => x.id === bk), 'backing-off connection skipped on next run');
ok(q(`select count(*) from cn_log where connection_id = '${bk}' and not ok`) >= 1, 'failure written to the message log');

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
