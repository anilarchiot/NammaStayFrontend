// Channex replaced by Beds24 (demo mode, desktop + phone): no Channex anywhere an owner or admin looks,
// OTA sync (Beds24) is the first card on the OTA page, the admin "OTA sync" button and the old Channex admin
// page both lead to Connections, and the legal pages name Beds24. iCal calendar sync is untouched.
// usage: node ui_no_channex.mjs http://localhost:PORT outDir
import { chromium } from '/opt/node22/lib/node_modules/playwright/index.mjs';
import fs from 'fs';
const B = process.argv[2]; const OUT = process.argv[3]; fs.mkdirSync(OUT, { recursive: true });
let pass = 0, fail = 0; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); c ? pass++ : fail++; };
const b = await chromium.launch();
for (const [w, tag] of [[1400, 'desk'], [390, 'phone']]) {
  const ctx = await b.newContext({ viewport: { width: w, height: 900 } }); const pg = await ctx.newPage();
  const errs = []; pg.on('pageerror', (e) => errs.push(e.message)); pg.on('console', (m) => { if (m.type() === 'error' && !/fonts\.g|ERR_/.test(m.text())) errs.push(m.text()); });
  const text = () => pg.evaluate(() => document.body.innerText);
  await pg.goto(B + '/login.html?demo=1');
  await pg.evaluate(() => { localStorage.clear(); localStorage.setItem('ns.demo.on', '1'); localStorage.setItem('ns.demo.kind', 'hostel'); localStorage.setItem('ns.demo.session', 'owner@demo.nammastay.in'); });

  for (const kind of ['hostel', 'hotel', 'homestay', 'resort']) {
    await pg.evaluate((k) => { localStorage.setItem('ns.demo.kind', k); localStorage.removeItem('ns.demo.v1'); localStorage.removeItem('ns.shell'); }, kind);
    await pg.goto(B + '/dashboard.html'); await pg.waitForTimeout(800);
    await pg.goto(B + '/ota.html'); await pg.waitForSelector('#cn-card .cn-sync', { timeout: 15000 }); await pg.waitForTimeout(1200);
    const t = await text();
    ok(!/channex|two-way channel manager|set up channel manager/i.test(t), `${tag} ${kind}: no Channex on the OTA sync page`);
    ok(await pg.locator('#cx-card').count() === 0, `${tag} ${kind}: Channex card not on the page`);
    const first = await pg.evaluate(() => document.querySelector('.ns-content #cn-card') === document.querySelector('.ns-content > *:not(style):not(script)') || !!document.querySelector('.ns-content > #cn-card:first-child'));
    ok(first && t.includes('Turn on OTA sync'), `${tag} ${kind}: OTA sync (Beds24) is the first card`);
    ok(await pg.locator('.ota-bed').count() > 0 && t.includes('Keep Airbnb, Booking.com and NammaStay in step'), `${tag} ${kind}: iCal calendar sync still there`);
    if (kind === 'hostel') await pg.screenshot({ path: `${OUT}/${tag}-ota-no-channex.png` });
  }

  await pg.goto(B + '/admin.html'); await pg.waitForSelector('.ns-sidebar a[href="connections.html"]', { timeout: 15000 }); await pg.waitForTimeout(500);
  const head = await pg.evaluate(() => [...document.querySelectorAll('a.ns-btn-ghost')].map((a) => `${a.textContent.trim()}→${a.getAttribute('href')}`));
  ok(head.includes('OTA sync→connections.html') && !head.some((x) => /channel-manager|Channel manager/.test(x)), `${tag}: admin header has "OTA sync" → Connections, no Channel manager [${head.join(', ')}]`);
  ok(!/channex/i.test(await text()), `${tag}: no Channex on the admin overview`);
  await pg.goto(B + '/channel-manager.html'); await pg.waitForURL(/connections\.html/, { timeout: 10000 }).catch(() => {});
  ok(/connections\.html$/.test(new URL(pg.url()).pathname), `${tag}: old Channex admin page opens Connections`);
  await pg.waitForSelector('text=OTA sync setup', { timeout: 15000 }).catch(() => {});
  ok(!/channex/i.test(await text()), `${tag}: no Channex on Connections`);
  for (const p of ['privacy', 'terms', 'refund']) {
    await pg.goto(`${B}/${p}.html`); const t = await text();
    ok(!/channex/i.test(t), `${tag}: no Channex on ${p}.html`);
  }
  ok(/Beds24/.test(await (async () => { await pg.goto(B + '/privacy.html'); return text(); })()), `${tag}: privacy page names Beds24`);
  ok(errs.length === 0, `${tag}: no JS errors ${errs.slice(0, 3).join(' | ')}`);
  await ctx.close();
}
await b.close();
console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
