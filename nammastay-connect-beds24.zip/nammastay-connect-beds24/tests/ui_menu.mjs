// Menu check (demo mode): "Connections" is in the NammaStay admin menu on every admin page, desktop and phone,
// is highlighted on its own page, opens the page, and also appears for admins inside the hostel app —
// including when the browser remembers a menu saved before Connections existed.
// usage: node ui_menu.mjs http://localhost:PORT outDir
import { chromium } from '/opt/node22/lib/node_modules/playwright/index.mjs';
import fs from 'fs';
const B = process.argv[2]; const OUT = process.argv[3]; fs.mkdirSync(OUT, { recursive: true });
let pass = 0, fail = 0; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); c ? pass++ : fail++; };
const ADMIN = ['admin', 'subscribers', 'revenue', 'leads', 'activity', 'channel-manager', 'connections'];
const WANT = ['Overview', 'Subscribers', 'Revenue & coupons', 'Leads', 'Activity log', 'Connections'];
const b = await chromium.launch();
for (const [w, tag] of [[1400, 'desk'], [390, 'phone']]) {
  const ctx = await b.newContext({ viewport: { width: w, height: 900 } }); const pg = await ctx.newPage();
  const errs = []; pg.on('pageerror', (e) => errs.push(e.message)); pg.on('console', (m) => { if (m.type() === 'error' && !/fonts\.g|ERR_/.test(m.text())) errs.push(m.text()); });
  const menu = () => pg.evaluate(() => [...document.querySelectorAll('.ns-sidebar .ns-nav a span')].map((s) => s.textContent.trim()));
  await pg.goto(B + '/login.html?demo=1');
  await pg.evaluate(() => { localStorage.clear(); localStorage.setItem('ns.demo.on', '1'); localStorage.setItem('ns.demo.kind', 'hostel'); localStorage.setItem('ns.demo.session', 'owner@demo.nammastay.in'); });

  // ---- admin area: every page shows the same admin menu, with Connections
  for (const p of ADMIN) {
    await pg.goto(`${B}/${p}.html`); await pg.waitForSelector('body.ns-admin-area .ns-sidebar a[href="connections.html"]', { timeout: 15000 }).catch(() => {});
    await pg.waitForTimeout(400);
    const m = await menu();
    ok(WANT.every((x) => m.includes(x)), `${tag}: ${p}.html admin menu has ${WANT.join(', ')}  [${m.join(' | ')}]`);
  }
  const act = await pg.evaluate(() => [...document.querySelectorAll('.ns-sidebar .ns-nav a.is-active span')].map((s) => s.textContent.trim()));
  ok(act.length === 1 && act[0] === 'Connections', `${tag}: Connections is highlighted on its own page (${act.join(',')})`);

  // ---- open it from the menu (phone: through the menu button)
  await pg.goto(`${B}/admin.html`); await pg.waitForSelector('.ns-sidebar a[href="connections.html"]', { timeout: 15000 });
  if (w < 900) { await pg.click('[data-nav-open]'); await pg.waitForTimeout(400); }
  ok(await pg.isVisible('.ns-sidebar a[href="connections.html"]'), `${tag}: Connections visible in the ${w < 900 ? 'phone menu' : 'sidebar'}`);
  if (w < 900) await pg.screenshot({ path: `${OUT}/${tag}-menu-open.png` });
  await pg.click('.ns-sidebar a[href="connections.html"]'); await pg.waitForURL(/connections\.html/, { timeout: 10000 });
  await pg.waitForSelector('text=OTA sync setup', { timeout: 15000 });
  ok(true, `${tag}: menu opens the Connections page`);
  if (w >= 900) await pg.screenshot({ path: `${OUT}/${tag}-connections-menu.png` });

  // ---- remembered admin menu from before Connections existed → still shows it after loading
  await pg.evaluate(() => { const s = JSON.parse(localStorage.getItem('ns.shell.admin')); const d = document.createElement('div'); d.innerHTML = s.nav;
    d.querySelectorAll('a[href="connections.html"]').forEach((a) => a.remove()); s.nav = d.innerHTML; localStorage.setItem('ns.shell.admin', JSON.stringify(s)); });
  await pg.goto(`${B}/subscribers.html`); await pg.waitForTimeout(1500);
  ok((await menu()).includes('Connections'), `${tag}: old remembered admin menu gets Connections`);

  // ---- inside the hostel app: the "NammaStay admin" section
  await pg.goto(`${B}/dashboard.html`); await pg.waitForSelector('.ns-sidebar a[data-admin-link]', { timeout: 15000 }); await pg.waitForTimeout(400);
  let m = await menu();
  ok(m.includes('OTA sync') && m.includes('Connections') && m.indexOf('Connections') > m.indexOf('Activity log'), `${tag}: hostel app menu has OTA sync, and Connections in the admin section`);
  // same, with a remembered app menu saved before Connections existed
  await pg.evaluate(() => { const s = JSON.parse(localStorage.getItem('ns.shell')); const d = document.createElement('div'); d.innerHTML = s.nav;
    d.querySelectorAll('a[href="connections.html"]').forEach((a) => a.remove()); s.nav = d.innerHTML; localStorage.setItem('ns.shell', JSON.stringify(s)); });
  await pg.goto(`${B}/calendar.html`); await pg.waitForTimeout(1500);
  m = await menu();
  ok(m.filter((x) => x === 'Connections').length === 1 && m.indexOf('Connections') === m.indexOf('Activity log') + 1, `${tag}: old remembered app menu gets Connections once, after Activity log`);
  await pg.goto(`${B}/bookings.html`); await pg.waitForTimeout(1200);
  ok((await menu()).filter((x) => x === 'Connections').length === 1, `${tag}: still exactly once on the next page`);
  ok(errs.length === 0, `${tag}: no JS errors ${errs.slice(0, 3).join(' | ')}`);
  await ctx.close();
}
// ---- a staff member (not a NammaStay admin) never sees admin links
{
  const ctx = await b.newContext({ viewport: { width: 1400, height: 900 } }); const pg = await ctx.newPage();
  await pg.goto(B + '/login.html?demo=1');
  await pg.evaluate(() => { localStorage.clear(); localStorage.setItem('ns.demo.on', '1'); localStorage.setItem('ns.demo.kind', 'hostel'); localStorage.setItem('ns.demo.session', 'owner@demo.nammastay.in'); });
  await pg.goto(B + '/dashboard.html'); await pg.waitForTimeout(1200);
  await pg.evaluate(() => { const d = JSON.parse(localStorage.getItem('ns.demo.v1')); d.viewAs = 'front_desk'; localStorage.setItem('ns.demo.v1', JSON.stringify(d)); localStorage.removeItem('ns.shell'); });
  await pg.goto(B + '/dashboard.html'); await pg.waitForTimeout(1500);
  const m = await pg.evaluate(() => [...document.querySelectorAll('.ns-sidebar .ns-nav a span')].map((s) => s.textContent.trim()));
  ok(!m.includes('OTA sync'), `front desk: no OTA sync in the menu (as before)`);
  await ctx.close();
}
await b.close();
console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
